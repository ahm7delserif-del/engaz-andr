package com.example

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.ui.components.EngazBottomNavigationBar
import com.example.ui.navigation.NavRoutes
import com.example.ui.theme.EngazTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Composable
  fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
  }

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent { EngazTheme { Greeting("Engaz", Modifier.padding(16.dp)) } }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }

  @Test
  fun arabic_navigation_bar_screenshot() {
    composeTestRule.setContent {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        EngazTheme(darkTheme = false) {
          Box(modifier = Modifier.fillMaxWidth()) {
            EngazBottomNavigationBar(
              currentRoute = NavRoutes.DASHBOARD,
              isArabic = true,
              isDark = false,
              onNavigate = {}
            )
          }
        }
      }
    }
    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/arabic_nav.png")
  }

  @Test
  fun english_navigation_bar_screenshot() {
    composeTestRule.setContent {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        EngazTheme(darkTheme = false) {
          Box(modifier = Modifier.fillMaxWidth()) {
            EngazBottomNavigationBar(
              currentRoute = NavRoutes.DASHBOARD,
              isArabic = false,
              isDark = false,
              onNavigate = {}
            )
          }
        }
      }
    }
    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/english_nav.png")
  }
}
