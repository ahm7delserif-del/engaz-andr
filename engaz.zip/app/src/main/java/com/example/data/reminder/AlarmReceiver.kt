package com.example.data.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "إنجاز"
        val message = intent.getStringExtra(EXTRA_MESSAGE) ?: "تذكير بمهمتك المجدولة"
        val notificationId = intent.getIntExtra(EXTRA_ID, System.currentTimeMillis().toInt())
        val isTimer = intent.getBooleanExtra(EXTRA_IS_TIMER, false)

        showNotification(context, title, message, notificationId, isTimer)
    }

    private fun showNotification(
        context: Context,
        title: String,
        message: String,
        notificationId: Int,
        isTimer: Boolean
    ) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId = if (isTimer) CHANNEL_ID_TIMER else CHANNEL_ID_REMINDER

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = if (isTimer) "مؤقتات المهام والأنشطة" else "تذكيرات إنجاز"
            val importance = if (isTimer) NotificationManager.IMPORTANCE_HIGH else NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = "إشعارات المهام والمؤقتات المجدولة في تطبيق إنجاز"
                enableVibration(true)
                vibrationPattern = if (isTimer) longArrayOf(0, 500, 200, 500, 200, 500) else longArrayOf(0, 250, 100, 250)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("SHOW_TIMER_COMPLETION", isTimer)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(
            if (isTimer) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(if (isTimer) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setSound(soundUri)
            .setVibrate(if (isTimer) longArrayOf(0, 500, 200, 500, 200, 500) else longArrayOf(0, 250, 100, 250))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        notificationManager.notify(notificationId, builder.build())
    }

    companion object {
        const val CHANNEL_ID_REMINDER = "engaz_reminders_channel"
        const val CHANNEL_ID_TIMER = "engaz_timers_channel"

        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_ID = "extra_id"
        const val EXTRA_IS_TIMER = "extra_is_timer"
    }
}
