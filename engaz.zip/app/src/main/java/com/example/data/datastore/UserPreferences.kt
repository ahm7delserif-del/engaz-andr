package com.example.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "engaz_user_preferences")

data class AppPreferences(
    val language: String = "ar", // default to Arabic or English
    val themeMode: String = "dark", // "dark", "light", "system"
    val appDisplayName: String = "إنجاز",
    val customLogoUri: String? = null,
    val selectedIconVariant: String = "dark", // "dark" (Logo.jpg) or "light" (Logo2.jpg)
    val weeklyReviewDay: Int = 5, // 5 = Friday (common in Arab world), or 7 = Sunday
    val waterGoalMl: Int = 3000,
    val currencySymbol: String = "EGP"
)

class UserPreferencesRepository(private val context: Context) {

    private object PreferenceKeys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val APP_DISPLAY_NAME = stringPreferencesKey("app_display_name")
        val CUSTOM_LOGO_URI = stringPreferencesKey("custom_logo_uri")
        val SELECTED_ICON_VARIANT = stringPreferencesKey("selected_icon_variant")
        val WEEKLY_REVIEW_DAY = intPreferencesKey("weekly_review_day")
        val WATER_GOAL_ML = intPreferencesKey("water_goal_ml")
        val CURRENCY_SYMBOL = stringPreferencesKey("currency_symbol")
    }

    val userPreferencesFlow: Flow<AppPreferences> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            AppPreferences(
                language = preferences[PreferenceKeys.LANGUAGE] ?: "ar",
                themeMode = preferences[PreferenceKeys.THEME_MODE] ?: "dark",
                appDisplayName = preferences[PreferenceKeys.APP_DISPLAY_NAME] ?: "إنجاز",
                customLogoUri = preferences[PreferenceKeys.CUSTOM_LOGO_URI],
                selectedIconVariant = preferences[PreferenceKeys.SELECTED_ICON_VARIANT] ?: "dark",
                weeklyReviewDay = preferences[PreferenceKeys.WEEKLY_REVIEW_DAY] ?: 5,
                waterGoalMl = preferences[PreferenceKeys.WATER_GOAL_ML] ?: 3000,
                currencySymbol = preferences[PreferenceKeys.CURRENCY_SYMBOL] ?: "EGP"
            )
        }

    suspend fun updateLanguage(language: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.LANGUAGE] = language
        }
    }

    suspend fun updateThemeMode(themeMode: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.THEME_MODE] = themeMode
        }
    }

    suspend fun updateAppIdentity(displayName: String, logoUri: String?) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.APP_DISPLAY_NAME] = displayName
            if (logoUri != null) {
                preferences[PreferenceKeys.CUSTOM_LOGO_URI] = logoUri
            } else {
                preferences.remove(PreferenceKeys.CUSTOM_LOGO_URI)
            }
        }
    }

    suspend fun restoreDefaultIdentity() {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.APP_DISPLAY_NAME] = "إنجاز"
            preferences.remove(PreferenceKeys.CUSTOM_LOGO_URI)
            preferences[PreferenceKeys.SELECTED_ICON_VARIANT] = "dark"
        }
    }

    suspend fun updateIconVariant(variant: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.SELECTED_ICON_VARIANT] = variant
        }
    }

    suspend fun updateWeeklyReviewDay(dayOfWeek: Int) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.WEEKLY_REVIEW_DAY] = dayOfWeek
        }
    }

    suspend fun updateWaterGoal(goalMl: Int) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.WATER_GOAL_ML] = goalMl
        }
    }

    suspend fun updateCurrency(currency: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.CURRENCY_SYMBOL] = currency
        }
    }
}
