package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY dueDate ASC, dueTime ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE dueDate = :date ORDER BY dueTime ASC")
    fun getTasksForDate(date: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getTaskById(id: Long): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Long)
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY time ASC")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits WHERE id = :id")
    suspend fun getHabitById(id: Long): HabitEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("DELETE FROM habits WHERE id = :id")
    suspend fun deleteHabitById(id: Long)

    // Logs
    @Query("SELECT * FROM habit_logs WHERE date = :date")
    fun getLogsForDate(date: String): Flow<List<HabitLogEntity>>

    @Query("SELECT * FROM habit_logs WHERE habitId = :habitId ORDER BY date DESC")
    fun getLogsForHabit(habitId: Long): Flow<List<HabitLogEntity>>

    @Query("SELECT * FROM habit_logs")
    fun getAllHabitLogs(): Flow<List<HabitLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: HabitLogEntity): Long

    @Query("DELETE FROM habit_logs WHERE habitId = :habitId AND date = :date")
    suspend fun deleteLogForDate(habitId: Long, date: String)
}

@Dao
interface HealthDao {
    // Workouts
    @Query("SELECT * FROM workouts ORDER BY date ASC, time ASC")
    fun getAllWorkouts(): Flow<List<WorkoutEntity>>

    @Query("SELECT * FROM workouts WHERE date = :date ORDER BY time ASC")
    fun getWorkoutsForDate(date: String): Flow<List<WorkoutEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkout(workout: WorkoutEntity): Long

    @Update
    suspend fun updateWorkout(workout: WorkoutEntity)

    @Delete
    suspend fun deleteWorkout(workout: WorkoutEntity)

    @Query("DELETE FROM workouts WHERE id = :id")
    suspend fun deleteWorkoutById(id: Long)

    // Fasting
    @Query("SELECT * FROM fasting_plans ORDER BY date ASC")
    fun getAllFastingPlans(): Flow<List<FastingPlanEntity>>

    @Query("SELECT * FROM fasting_plans WHERE date = :date LIMIT 1")
    fun getFastingPlanForDate(date: String): Flow<FastingPlanEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFastingPlan(plan: FastingPlanEntity): Long

    @Update
    suspend fun updateFastingPlan(plan: FastingPlanEntity)

    @Query("DELETE FROM fasting_plans WHERE date = :date")
    suspend fun deleteFastingPlanForDate(date: String)

    // Water
    @Query("SELECT * FROM water_logs WHERE date = :date ORDER BY timestamp DESC")
    fun getWaterLogsForDate(date: String): Flow<List<WaterLogEntity>>

    @Query("SELECT SUM(amountMl) FROM water_logs WHERE date = :date")
    fun getTotalWaterForDate(date: String): Flow<Int?>

    @Query("SELECT * FROM water_logs")
    fun getAllWaterLogs(): Flow<List<WaterLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWaterLog(waterLog: WaterLogEntity): Long

    @Query("DELETE FROM water_logs WHERE id = :id")
    suspend fun deleteWaterLog(id: Long)

    @Query("DELETE FROM water_logs WHERE date = :date")
    suspend fun clearWaterLogsForDate(date: String)
}

@Dao
interface FinanceDao {
    // Commitments
    @Query("SELECT * FROM finance_commitments ORDER BY dueDayOfMonth ASC")
    fun getAllCommitments(): Flow<List<FinanceCommitmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommitment(commitment: FinanceCommitmentEntity): Long

    @Update
    suspend fun updateCommitment(commitment: FinanceCommitmentEntity)

    @Delete
    suspend fun deleteCommitment(commitment: FinanceCommitmentEntity)

    // Expenses
    @Query("SELECT * FROM finance_expenses ORDER BY date DESC, createdAt DESC")
    fun getAllExpenses(): Flow<List<FinanceExpenseEntity>>

    @Query("SELECT * FROM finance_expenses WHERE date = :date")
    fun getExpensesForDate(date: String): Flow<List<FinanceExpenseEntity>>

    @Query("SELECT * FROM finance_expenses WHERE date LIKE :monthPrefix || '%'")
    fun getExpensesForMonth(monthPrefix: String): Flow<List<FinanceExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: FinanceExpenseEntity): Long

    @Delete
    suspend fun deleteExpense(expense: FinanceExpenseEntity)

    // Savings Goals
    @Query("SELECT * FROM savings_goals ORDER BY targetDate ASC")
    fun getAllSavingsGoals(): Flow<List<SavingsGoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavingsGoal(goal: SavingsGoalEntity): Long

    @Update
    suspend fun updateSavingsGoal(goal: SavingsGoalEntity)

    @Delete
    suspend fun deleteSavingsGoal(goal: SavingsGoalEntity)

    // Income
    @Query("SELECT * FROM monthly_income WHERE monthYear = :monthYear LIMIT 1")
    fun getMonthlyIncome(monthYear: String): Flow<MonthlyIncomeEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMonthlyIncome(income: MonthlyIncomeEntity): Long
}

@Dao
interface GamingDao {
    @Query("SELECT * FROM games ORDER BY totalMinutesPlayed DESC")
    fun getAllGames(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE id = :id")
    suspend fun getGameById(id: Long): GameEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameEntity): Long

    @Update
    suspend fun updateGame(game: GameEntity)

    @Delete
    suspend fun deleteGame(game: GameEntity)

    // Sessions
    @Query("SELECT * FROM gaming_sessions ORDER BY timestamp DESC")
    fun getAllSessions(): Flow<List<GamingSessionEntity>>

    @Query("SELECT * FROM gaming_sessions WHERE date = :date")
    fun getSessionsForDate(date: String): Flow<List<GamingSessionEntity>>

    @Query("SELECT * FROM gaming_sessions WHERE date LIKE :monthPrefix || '%'")
    fun getSessionsForMonth(monthPrefix: String): Flow<List<GamingSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: GamingSessionEntity): Long
}

@Dao
interface TimerDao {
    @Query("SELECT * FROM active_timer WHERE id = 1 LIMIT 1")
    fun getActiveTimer(): Flow<ActiveTimerEntity?>

    @Query("SELECT * FROM active_timer WHERE id = 1 LIMIT 1")
    suspend fun getActiveTimerSync(): ActiveTimerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveActiveTimer(timer: ActiveTimerEntity)

    @Query("DELETE FROM active_timer WHERE id = 1")
    suspend fun clearActiveTimer()
}
