package com.example.data.repository

import com.example.data.local.dao.*
import com.example.data.local.entity.*
import com.example.data.reminder.NotificationScheduler
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class TaskRepository(
    private val taskDao: TaskDao,
    private val scheduler: NotificationScheduler
) {
    fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks()
    fun getTasksForDate(date: String): Flow<List<TaskEntity>> = taskDao.getTasksForDate(date)

    suspend fun insertTask(task: TaskEntity): Long {
        val id = taskDao.insertTask(task)
        scheduleReminder(task.copy(id = id))
        return id
    }

    suspend fun updateTask(task: TaskEntity) {
        taskDao.updateTask(task)
        scheduler.cancelAlarm(task.id.toInt())
        if (task.status != "COMPLETED") {
            scheduleReminder(task)
        }
    }

    suspend fun deleteTask(task: TaskEntity) {
        scheduler.cancelAlarm(task.id.toInt())
        taskDao.deleteTask(task)
    }

    private fun scheduleReminder(task: TaskEntity) {
        val triggerTime = parseDateAndTimeToMillis(task.dueDate, task.dueTime)
        if (triggerTime != null && triggerTime > System.currentTimeMillis()) {
            scheduler.scheduleAlarm(
                id = task.id.toInt(),
                title = "مهمة مجدولة: ${task.title}",
                message = "حان وقت إنجاز مهمتك (${task.dueTime})",
                triggerTimeMillis = triggerTime,
                isTimer = false
            )
        }
    }

    private fun parseDateAndTimeToMillis(date: String, time: String): Long? {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            sdf.parse("$date $time")?.time
        } catch (e: Exception) {
            null
        }
    }
}

class HabitRepository(
    private val habitDao: HabitDao,
    private val scheduler: NotificationScheduler
) {
    fun getAllHabits(): Flow<List<HabitEntity>> = habitDao.getAllHabits()
    fun getLogsForDate(date: String): Flow<List<HabitLogEntity>> = habitDao.getLogsForDate(date)
    fun getAllHabitLogs(): Flow<List<HabitLogEntity>> = habitDao.getAllHabitLogs()
    fun getLogsForHabit(habitId: Long): Flow<List<HabitLogEntity>> = habitDao.getLogsForHabit(habitId)

    suspend fun insertHabit(habit: HabitEntity): Long {
        val id = habitDao.insertHabit(habit)
        return id
    }

    suspend fun updateHabit(habit: HabitEntity) {
        habitDao.updateHabit(habit)
    }

    suspend fun deleteHabit(habit: HabitEntity) {
        scheduler.cancelAlarm((10000 + habit.id).toInt())
        habitDao.deleteHabit(habit)
    }

    suspend fun logHabitProgress(log: HabitLogEntity) {
        habitDao.insertLog(log)
    }

    suspend fun deleteLogForDate(habitId: Long, date: String) {
        habitDao.deleteLogForDate(habitId, date)
    }
}

class HealthRepository(
    private val healthDao: HealthDao,
    private val scheduler: NotificationScheduler
) {
    // Workouts
    fun getAllWorkouts(): Flow<List<WorkoutEntity>> = healthDao.getAllWorkouts()
    fun getWorkoutsForDate(date: String): Flow<List<WorkoutEntity>> = healthDao.getWorkoutsForDate(date)

    suspend fun insertWorkout(workout: WorkoutEntity): Long {
        val id = healthDao.insertWorkout(workout)
        scheduler.scheduleDualHealthReminder(
            baseId = (20000 + id).toInt(),
            title = "تمرين: ${workout.title}",
            dateStr = workout.date,
            timeStr = workout.time
        )
        return id
    }

    suspend fun updateWorkout(workout: WorkoutEntity) {
        healthDao.updateWorkout(workout)
        scheduler.cancelDualHealthReminder((20000 + workout.id).toInt())
        if (workout.status != "COMPLETED") {
            scheduler.scheduleDualHealthReminder(
                baseId = (20000 + workout.id).toInt(),
                title = "تمرين: ${workout.title}",
                dateStr = workout.date,
                timeStr = workout.time
            )
        }
    }

    suspend fun deleteWorkout(workout: WorkoutEntity) {
        scheduler.cancelDualHealthReminder((20000 + workout.id).toInt())
        healthDao.deleteWorkout(workout)
    }

    // Fasting
    fun getAllFastingPlans(): Flow<List<FastingPlanEntity>> = healthDao.getAllFastingPlans()
    fun getFastingPlanForDate(date: String): Flow<FastingPlanEntity?> = healthDao.getFastingPlanForDate(date)

    suspend fun saveFastingPlan(plan: FastingPlanEntity): Long = healthDao.insertFastingPlan(plan)
    suspend fun updateFastingPlan(plan: FastingPlanEntity) = healthDao.updateFastingPlan(plan)
    suspend fun deleteFastingPlanForDate(date: String) = healthDao.deleteFastingPlanForDate(date)

    // Water
    fun getWaterLogsForDate(date: String): Flow<List<WaterLogEntity>> = healthDao.getWaterLogsForDate(date)
    fun getTotalWaterForDate(date: String): Flow<Int?> = healthDao.getTotalWaterForDate(date)
    fun getAllWaterLogs(): Flow<List<WaterLogEntity>> = healthDao.getAllWaterLogs()

    suspend fun logWater(amountMl: Int, date: String) {
        healthDao.insertWaterLog(
            WaterLogEntity(
                date = date,
                amountMl = amountMl
            )
        )
    }

    suspend fun clearWaterLogsForDate(date: String) {
        healthDao.clearWaterLogsForDate(date)
    }
}

class FinanceRepository(private val financeDao: FinanceDao) {
    fun getAllCommitments(): Flow<List<FinanceCommitmentEntity>> = financeDao.getAllCommitments()
    suspend fun insertCommitment(item: FinanceCommitmentEntity) = financeDao.insertCommitment(item)
    suspend fun updateCommitment(item: FinanceCommitmentEntity) = financeDao.updateCommitment(item)
    suspend fun deleteCommitment(item: FinanceCommitmentEntity) = financeDao.deleteCommitment(item)

    fun getAllExpenses(): Flow<List<FinanceExpenseEntity>> = financeDao.getAllExpenses()
    fun getExpensesForDate(date: String): Flow<List<FinanceExpenseEntity>> = financeDao.getExpensesForDate(date)
    fun getExpensesForMonth(monthPrefix: String): Flow<List<FinanceExpenseEntity>> = financeDao.getExpensesForMonth(monthPrefix)
    suspend fun insertExpense(item: FinanceExpenseEntity) = financeDao.insertExpense(item)
    suspend fun deleteExpense(item: FinanceExpenseEntity) = financeDao.deleteExpense(item)

    fun getAllSavingsGoals(): Flow<List<SavingsGoalEntity>> = financeDao.getAllSavingsGoals()
    suspend fun insertSavingsGoal(goal: SavingsGoalEntity) = financeDao.insertSavingsGoal(goal)
    suspend fun updateSavingsGoal(goal: SavingsGoalEntity) = financeDao.updateSavingsGoal(goal)
    suspend fun deleteSavingsGoal(goal: SavingsGoalEntity) = financeDao.deleteSavingsGoal(goal)

    fun getMonthlyIncome(monthYear: String): Flow<MonthlyIncomeEntity?> = financeDao.getMonthlyIncome(monthYear)
    suspend fun setMonthlyIncome(monthYear: String, amount: Double) {
        financeDao.insertMonthlyIncome(
            MonthlyIncomeEntity(
                monthYear = monthYear,
                incomeAmount = amount
            )
        )
    }
}

class GamingRepository(private val gamingDao: GamingDao) {
    fun getAllGames(): Flow<List<GameEntity>> = gamingDao.getAllGames()
    suspend fun insertGame(game: GameEntity) = gamingDao.insertGame(game)
    suspend fun updateGame(game: GameEntity) = gamingDao.updateGame(game)
    suspend fun deleteGame(game: GameEntity) = gamingDao.deleteGame(game)

    fun getAllSessions(): Flow<List<GamingSessionEntity>> = gamingDao.getAllSessions()
    fun getSessionsForDate(date: String): Flow<List<GamingSessionEntity>> = gamingDao.getSessionsForDate(date)
    fun getSessionsForMonth(monthPrefix: String): Flow<List<GamingSessionEntity>> = gamingDao.getSessionsForMonth(monthPrefix)

    suspend fun recordSession(gameId: Long, gameName: String, durationMinutes: Int, date: String) {
        gamingDao.insertSession(
            GamingSessionEntity(
                gameId = gameId,
                gameName = gameName,
                durationMinutes = durationMinutes,
                date = date
            )
        )
        // Update game total minutes
        val game = gamingDao.getGameById(gameId)
        if (game != null) {
            gamingDao.updateGame(game.copy(totalMinutesPlayed = game.totalMinutesPlayed + durationMinutes))
        }
    }
}

class TimerRepository(
    private val timerDao: TimerDao,
    private val scheduler: NotificationScheduler
) {
    val activeTimerFlow: Flow<ActiveTimerEntity?> = timerDao.getActiveTimer()

    suspend fun getActiveTimerSync(): ActiveTimerEntity? = timerDao.getActiveTimerSync()

    suspend fun startTimer(
        activityId: Long,
        activityType: String,
        activityTitle: String,
        durationMinutes: Int
    ) {
        val startTime = System.currentTimeMillis()
        val endTime = startTime + (durationMinutes * 60 * 1000L)

        val timer = ActiveTimerEntity(
            id = 1,
            activityId = activityId,
            activityType = activityType,
            activityTitle = activityTitle,
            startTimeMillis = startTime,
            endTimeMillis = endTime,
            totalDurationMinutes = durationMinutes,
            isRunning = true
        )
        timerDao.saveActiveTimer(timer)

        // Schedule timer notification & alarm
        scheduler.scheduleAlarm(
            id = 99999,
            title = "انتهى وقت النشاط: $activityTitle",
            message = "انتهت مدة $durationMinutes دقيقة المحددة. هل أنجزت هذه المهمة بنجاح؟",
            triggerTimeMillis = endTime,
            isTimer = true
        )
    }

    suspend fun clearActiveTimer() {
        scheduler.cancelAlarm(99999)
        timerDao.clearActiveTimer()
    }
}
