package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "WORK", // WORK, STUDY, PERSONAL_PROJECT
    val priority: String = "MEDIUM", // HIGH, MEDIUM, LOW
    val dueDate: String, // YYYY-MM-DD
    val dueTime: String = "09:00", // HH:mm
    val estimatedDurationMinutes: Int = 30,
    val status: String = "PENDING", // PENDING, IN_PROGRESS, COMPLETED, POSTPONED, OVERDUE
    val completionReason: String? = null,
    val notes: String = "",
    val thumbnailUri: String? = null,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "MIND", // MIND, READING, QURAN, STUDY, CUSTOM
    val recurrenceType: String = "DAILY", // DAILY, WEEKDAYS, DATE_RANGE
    val recurrenceDays: String = "MON,TUE,WED,THU,FRI,SAT,SUN", // comma separated
    val startDate: String? = null, // YYYY-MM-DD
    val endDate: String? = null, // YYYY-MM-DD
    val time: String = "08:00", // HH:mm
    val durationMinutes: Int = 20,
    val targetNumeric: Float = 1f,
    val targetUnit: String = "unit", // pages, parts, lessons, minutes
    val thumbnailUri: String? = null,
    val streak: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "habit_logs")
data class HabitLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val date: String, // YYYY-MM-DD
    val status: String = "COMPLETED", // COMPLETED, PARTIAL, MISSED, POSTPONED
    val progressValue: Float = 0f,
    val notes: String = "",
    val incompleteReason: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "workouts")
data class WorkoutEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val date: String, // YYYY-MM-DD
    val weekday: String = "", // e.g. MONDAY
    val time: String = "07:00", // HH:mm
    val durationMinutes: Int = 45,
    val thumbnailUri: String? = null,
    val status: String = "PENDING", // PENDING, COMPLETED, MISSED, POSTPONED
    val incompleteReason: String? = null,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "fasting_plans")
data class FastingPlanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String, // YYYY-MM-DD
    val type: String = "SUNNAH_MON_THU", // SUNNAH_MON_THU, WHITE_DAYS, CUSTOM, RAMADAN
    val status: String = "PLANNED", // PLANNED, FASTING, COMPLETED, BROKEN
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "water_logs")
data class WaterLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String, // YYYY-MM-DD
    val amountMl: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "finance_commitments")
data class FinanceCommitmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val category: String = "BILLS", // RENT, BILLS, SUBSCRIPTION, INSTALLMENT, OTHER
    val dueDayOfMonth: Int = 1,
    val isMonthlyRecurring: Boolean = true,
    val isPaidThisMonth: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "finance_expenses")
data class FinanceExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val category: String = "FOOD", // FOOD, TRANSPORT, SHOPPING, HEALTH, EDUCATION, BILLS, OTHER
    val date: String, // YYYY-MM-DD
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double = 0.0,
    val targetDate: String, // YYYY-MM-DD
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "monthly_income")
data class MonthlyIncomeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val monthYear: String, // YYYY-MM
    val incomeAmount: Double
)

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val thumbnailUri: String? = null,
    val totalMinutesPlayed: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "gaming_sessions")
data class GamingSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameId: Long,
    val gameName: String,
    val durationMinutes: Int,
    val date: String, // YYYY-MM-DD
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "active_timer")
data class ActiveTimerEntity(
    @PrimaryKey val id: Int = 1, // Single active timer state
    val activityId: Long,
    val activityType: String, // TASK, HABIT, WORKOUT, GAME
    val activityTitle: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val totalDurationMinutes: Int,
    val isRunning: Boolean = true
)
