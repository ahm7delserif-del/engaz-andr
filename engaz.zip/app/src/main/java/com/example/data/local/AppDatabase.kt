package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.*
import com.example.data.local.entity.*

@Database(
    entities = [
        TaskEntity::class,
        HabitEntity::class,
        HabitLogEntity::class,
        WorkoutEntity::class,
        FastingPlanEntity::class,
        WaterLogEntity::class,
        FinanceCommitmentEntity::class,
        FinanceExpenseEntity::class,
        SavingsGoalEntity::class,
        MonthlyIncomeEntity::class,
        GameEntity::class,
        GamingSessionEntity::class,
        ActiveTimerEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun habitDao(): HabitDao
    abstract fun healthDao(): HealthDao
    abstract fun financeDao(): FinanceDao
    abstract fun gamingDao(): GamingDao
    abstract fun timerDao(): TimerDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "engaz_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
