package com.example.data.reminder

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

class NotificationScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    @SuppressLint("ScheduleExactAlarm")
    fun scheduleAlarm(
        id: Int,
        title: String,
        message: String,
        triggerTimeMillis: Long,
        isTimer: Boolean = false
    ) {
        if (alarmManager == null || triggerTimeMillis <= System.currentTimeMillis()) {
            return
        }

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.aistudio.engaz.ACTION_ALARM"
            putExtra(AlarmReceiver.EXTRA_ID, id)
            putExtra(AlarmReceiver.EXTRA_TITLE, title)
            putExtra(AlarmReceiver.EXTRA_MESSAGE, message)
            putExtra(AlarmReceiver.EXTRA_IS_TIMER, isTimer)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTimeMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        triggerTimeMillis,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTimeMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            Log.w("NotificationScheduler", "Exact alarm permission missing, fallback to standard alarm", e)
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerTimeMillis,
                pendingIntent
            )
        } catch (e: Exception) {
            Log.e("NotificationScheduler", "Failed to schedule alarm", e)
        }
    }

    fun cancelAlarm(id: Int) {
        if (alarmManager == null) return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.aistudio.engaz.ACTION_ALARM"
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    /**
     * Schedule dual reminders for health activities:
     * 1) 10 minutes before the scheduled time
     * 2) Exactly at the scheduled time
     */
    fun scheduleDualHealthReminder(
        baseId: Int,
        title: String,
        dateStr: String, // YYYY-MM-DD
        timeStr: String // HH:mm
    ) {
        val targetMillis = parseDateTimeToMillis(dateStr, timeStr) ?: return
        val tenMinutesBeforeMillis = targetMillis - (10 * 60 * 1000L)

        // 10 minutes before
        if (tenMinutesBeforeMillis > System.currentTimeMillis()) {
            scheduleAlarm(
                id = baseId * 10 + 1,
                title = title,
                message = "تنبيه: يبدأ نشاطك الصحي بعد 10 دقائق!",
                triggerTimeMillis = tenMinutesBeforeMillis,
                isTimer = false
            )
        }

        // Exact time
        if (targetMillis > System.currentTimeMillis()) {
            scheduleAlarm(
                id = baseId * 10 + 2,
                title = title,
                message = "حان الآن موعد نشاطك الصحي!",
                triggerTimeMillis = targetMillis,
                isTimer = false
            )
        }
    }

    fun cancelDualHealthReminder(baseId: Int) {
        cancelAlarm(baseId * 10 + 1)
        cancelAlarm(baseId * 10 + 2)
    }

    private fun parseDateTimeToMillis(dateStr: String, timeStr: String): Long? {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val date = sdf.parse("$dateStr $timeStr")
            date?.time
        } catch (e: Exception) {
            null
        }
    }
}
