package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.ActiveTimerEntity
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun ActiveTimerBanner(
    timer: ActiveTimerEntity?,
    onStopTimer: () -> Unit,
    onCompleteTask: (ActiveTimerEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    if (timer == null) return

    var remainingSeconds by remember(timer.endTimeMillis) {
        val diff = (timer.endTimeMillis - System.currentTimeMillis()) / 1000L
        mutableLongStateOf(diff.coerceAtLeast(0L))
    }

    LaunchedEffect(timer.endTimeMillis) {
        while (true) {
            val diff = (timer.endTimeMillis - System.currentTimeMillis()) / 1000L
            remainingSeconds = diff.coerceAtLeast(0L)
            if (diff <= 0) break
            delay(1000L)
        }
    }

    val totalSeconds = (timer.totalDurationMinutes * 60L).coerceAtLeast(1L)
    val progress = (1f - (remainingSeconds.toFloat() / totalSeconds.toFloat())).coerceIn(0f, 1f)

    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val timeFormatted = String.format("%02d:%02d", minutes, seconds)
    val isFinished = remainingSeconds <= 0

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(
                width = 1.5.dp,
                color = if (isFinished) StatusWarning else PrimaryLimeGreen,
                shape = RoundedCornerShape(18.dp)
            ),
        color = MainCharcoal,
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isFinished) StatusWarning.copy(alpha = 0.2f) else PrimaryLimeGreen.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = if (isFinished) Icons.Default.HourglassBottom else Icons.Default.Timer,
                            contentDescription = null,
                            tint = if (isFinished) StatusWarning else PrimaryLimeGreen,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = timer.activityTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = LightGray
                        )
                        Text(
                            text = if (isFinished) "انتهى الوقت المحدد!" else "المؤقت قيد التشغيل",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark
                        )
                    }
                }

                Text(
                    text = timeFormatted,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = if (isFinished) StatusWarning else PrimaryLimeGreen
                )
            }

            Spacer(Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (isFinished) StatusWarning else PrimaryLimeGreen,
                trackColor = DeepDark
            )

            Spacer(Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                TextButton(
                    onClick = onStopTimer,
                    colors = ButtonDefaults.textButtonColors(contentColor = StatusError),
                    modifier = Modifier.testTag("timer_cancel_button")
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.stop)
                }

                Spacer(Modifier.width(8.dp))

                Button(
                    onClick = { onCompleteTask(timer) },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLimeGreen),
                    modifier = Modifier.testTag("timer_complete_button")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.complete)
                }
            }
        }
    }
}
