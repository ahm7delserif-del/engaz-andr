package com.example.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.datastore.AppPreferences
import com.example.data.datastore.UserPreferencesRepository
import com.example.data.local.entity.*
import com.example.data.repository.*
import com.example.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class PerformanceMetric(
    val title: String,
    val value: String,
    val subtitle: String
)

data class ReasonCount(
    val reason: String,
    val count: Int
)

data class ReportsUiState(
    val selectedPeriod: String = "DAILY", // DAILY, MONTHLY, YEARLY, WEEKLY_REVIEW
    val completionRate: Int = 0,
    val completedTasksCount: Int = 0,
    val totalTasksCount: Int = 0,
    val totalWaterDrankLiters: Float = 0f,
    val totalWorkoutMinutes: Int = 0,
    val totalReadingPages: Int = 0,
    val totalQuranParts: Int = 0,
    val metricsList: List<PerformanceMetric> = emptyList(),
    val commonReasons: List<ReasonCount> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val weeklyReviewDay: Int = 5
)

class ReportsViewModel(
    private val taskRepository: TaskRepository,
    private val habitRepository: HabitRepository,
    private val healthRepository: HealthRepository,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()

    init {
        loadReports()
    }

    private fun loadReports() {
        val today = DateUtils.getTodayDateString()
        val currentMonth = DateUtils.getCurrentMonthString()

        viewModelScope.launch {
            combine(
                taskRepository.getAllTasks(),
                combine(
                    habitRepository.getAllHabits(),
                    habitRepository.getAllHabitLogs()
                ) { habits, logs -> Pair(habits, logs) },
                combine(
                    healthRepository.getAllWorkouts(),
                    healthRepository.getAllWaterLogs()
                ) { workouts, water -> Pair(workouts, water) },
                preferencesRepository.userPreferencesFlow
            ) { tasks, (habits, habitLogs), (workouts, waterLogs), prefs ->
                val completedTasks = tasks.count { it.status == "COMPLETED" }
                val totalTasks = tasks.size.coerceAtLeast(1)
                val taskRate = (completedTasks * 100) / totalTasks

                val totalWaterMl = waterLogs.sumOf { it.amountMl }
                val waterLiters = totalWaterMl / 1000f

                val workoutMins = workouts.filter { it.status == "COMPLETED" }.sumOf { it.durationMinutes }

                // Habit quantities
                var pages = 0
                var quranParts = 0
                habitLogs.filter { it.status == "COMPLETED" }.forEach { log ->
                    val habit = habits.find { it.id == log.habitId }
                    if (habit != null) {
                        if (habit.targetUnit.contains("صفحة") || habit.targetUnit.contains("page", ignoreCase = true)) {
                            pages += log.progressValue.toInt()
                        } else if (habit.targetUnit.contains("جزء") || habit.targetUnit.contains("حزب") || habit.targetUnit.contains("part", ignoreCase = true)) {
                            quranParts += log.progressValue.toInt()
                        }
                    }
                }

                // Incomplete reasons
                val reasonsMap = mutableMapOf<String, Int>()
                tasks.mapNotNull { it.completionReason }.filter { it.isNotBlank() }.forEach { reason ->
                    reasonsMap[reason] = (reasonsMap[reason] ?: 0) + 1
                }
                habitLogs.mapNotNull { it.incompleteReason }.filter { it.isNotBlank() }.forEach { reason ->
                    reasonsMap[reason] = (reasonsMap[reason] ?: 0) + 1
                }
                workouts.mapNotNull { it.incompleteReason }.filter { it.isNotBlank() }.forEach { reason ->
                    reasonsMap[reason] = (reasonsMap[reason] ?: 0) + 1
                }

                val reasonsList = reasonsMap.entries.map { ReasonCount(it.key, it.value) }.sortedByDescending { it.count }

                val suggestionsList = mutableListOf<String>()
                if (reasonsList.any { it.reason.contains("وقت") || it.reason.contains("time", ignoreCase = true) }) {
                    suggestionsList.add("اقتراح: قسّم المهام الكبيرة إلى فترات تركيز مدتها 25 دقيقة (بومودورو) لتفادي ضيق الوقت.")
                }
                if (reasonsList.any { it.reason.contains("تأجيل") || it.reason.contains("postpone", ignoreCase = true) }) {
                    suggestionsList.add("اقتراح: حدد المهمة الأكثر أهمية فور استيقاظك في الصباح الباكر لضمان إنجازها أولاً.")
                }
                if (reasonsList.any { it.reason.contains("جاهزية") || it.reason.contains("تحضير") || it.reason.contains("prep", ignoreCase = true) }) {
                    suggestionsList.add("اقتراح: جهّز أدواتك ومراجعك في الليلة السابقة لتوفير طاقة البداية في الصباح.")
                }
                if (suggestionsList.isEmpty()) {
                    suggestionsList.add("أداؤك متوازن ومميز! حافظ على وتيرة العادات اليومية لتعزيز قوة الالتزام الذاتي.")
                    suggestionsList.add("تذكّر أن الاستمرارية الصغيرة يومياً تفوق الحماس المنقطع.")
                }

                val metrics = listOf(
                    PerformanceMetric("المهام المكتملة", "$completedTasks / ${tasks.size}", "نسبة الإنجاز: $taskRate%"),
                    PerformanceMetric("شرب الماء الإجمالي", String.format("%.1f لتر", waterLiters), "معدل الحيوية البدنية"),
                    PerformanceMetric("التمارين الرياضية", "$workoutMins دقيقة", "إجمالي الوقت البدني النشط"),
                    PerformanceMetric("القراءة والمعرفة", "$pages صفحة", "إنجاز فكري متواصل"),
                    PerformanceMetric("القرآن الكريم", "$quranParts جزء/حزب", "بركة وردك الثابت")
                )

                ReportsUiState(
                    completionRate = taskRate,
                    completedTasksCount = completedTasks,
                    totalTasksCount = tasks.size,
                    totalWaterDrankLiters = waterLiters,
                    totalWorkoutMinutes = workoutMins,
                    totalReadingPages = pages,
                    totalQuranParts = quranParts,
                    metricsList = metrics,
                    commonReasons = reasonsList,
                    suggestions = suggestionsList,
                    weeklyReviewDay = prefs.weeklyReviewDay
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun setPeriod(period: String) {
        _uiState.update { it.copy(selectedPeriod = period) }
    }

    fun updateWeeklyReviewDay(day: Int) {
        viewModelScope.launch {
            preferencesRepository.updateWeeklyReviewDay(day)
            _uiState.update { it.copy(weeklyReviewDay = day) }
        }
    }
}
