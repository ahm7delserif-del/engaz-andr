package com.example.ui.navigation

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.*
import androidx.compose.material3.ripple
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.datastore.AppPreferences
import com.example.ui.components.AppTopBar
import com.example.ui.components.EngazBottomNavigationBar
import com.example.ui.localization.ArabicStrings
import com.example.ui.localization.EnglishStrings
import com.example.ui.localization.LocalAppStrings
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.dashboard.DashboardViewModel
import com.example.ui.screens.finance.FinanceScreen
import com.example.ui.screens.finance.FinanceViewModel
import com.example.ui.screens.gaming.GamingScreen
import com.example.ui.screens.gaming.GamingViewModel
import com.example.ui.screens.habits.HabitsScreen
import com.example.ui.screens.habits.HabitsViewModel
import com.example.ui.screens.health.HealthScreen
import com.example.ui.screens.health.HealthViewModel
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.reports.ReportsViewModel
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.SettingsViewModel
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.EngazTheme
import com.example.ui.theme.LightGray
import com.example.ui.theme.MainCharcoal
import com.example.ui.theme.PrimaryLimeGreen

@Composable
fun MainAppContainer(
    preferences: AppPreferences,
    dashboardViewModel: DashboardViewModel,
    habitsViewModel: HabitsViewModel,
    healthViewModel: HealthViewModel,
    financeViewModel: FinanceViewModel,
    gamingViewModel: GamingViewModel,
    tasksViewModel: com.example.ui.screens.tasks.TasksViewModel,
    reportsViewModel: ReportsViewModel,
    settingsViewModel: SettingsViewModel
) {
    val isArabic = preferences.language == "ar"
    val strings = if (isArabic) ArabicStrings else EnglishStrings
    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    val systemDark = isSystemInDarkTheme()
    val isDark = when (preferences.themeMode) {
        "light" -> false
        "dark" -> true
        else -> systemDark
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalAppStrings provides strings
    ) {
        EngazTheme(darkTheme = isDark) {
            val navController = rememberNavController()
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route ?: NavRoutes.DASHBOARD

            Scaffold(
                topBar = {
                    AppTopBar(
                        preferences = preferences,
                        onNavigateToSettings = {
                            if (currentRoute != NavRoutes.SETTINGS) {
                                navController.navigate(NavRoutes.SETTINGS)
                            }
                        }
                    )
                },
                bottomBar = {
                    EngazBottomNavigationBar(
                        currentRoute = currentRoute,
                        isArabic = isArabic,
                        isDark = isDark,
                        onNavigate = { route ->
                            if (currentRoute != route) {
                                navController.navigate(route) {
                                    popUpTo(NavRoutes.DASHBOARD) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = NavRoutes.DASHBOARD,
                    modifier = Modifier.padding(innerPadding)
                ) {
                    composable(NavRoutes.DASHBOARD) {
                        DashboardScreen(
                            viewModel = dashboardViewModel,
                            preferences = preferences,
                            onNavigateToSection = { route -> navController.navigate(route) }
                        )
                    }
                    composable(NavRoutes.TASKS) {
                        com.example.ui.screens.tasks.TasksScreen(viewModel = tasksViewModel)
                    }
                    composable(NavRoutes.HABITS) {
                        HabitsScreen(viewModel = habitsViewModel)
                    }
                    composable(NavRoutes.HEALTH) {
                        HealthScreen(viewModel = healthViewModel)
                    }
                    composable(NavRoutes.FINANCE) {
                        FinanceScreen(viewModel = financeViewModel, preferences = preferences)
                    }
                    composable(NavRoutes.GAMING) {
                        GamingScreen(viewModel = gamingViewModel)
                    }
                    composable(NavRoutes.REPORTS) {
                        ReportsScreen(viewModel = reportsViewModel)
                    }
                    composable(NavRoutes.SETTINGS) {
                        SettingsScreen(viewModel = settingsViewModel)
                    }
                }
            }
        }
    }
}
