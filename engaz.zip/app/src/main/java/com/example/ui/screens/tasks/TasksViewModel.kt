package com.example.ui.screens.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.TaskRepository
import com.example.data.repository.TimerRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TasksUiState(
    val tasks: List<TaskEntity> = emptyList(),
    val filteredTasks: List<TaskEntity> = emptyList(),
    val selectedFilter: String = "ALL", // ALL, WORK, STUDY, PROJECT, COMPLETED, PENDING
    val showAddEditDialog: Boolean = false,
    val selectedTaskForEdit: TaskEntity? = null,
    val taskToDelete: TaskEntity? = null
)

class TasksViewModel(
    private val taskRepository: TaskRepository,
    private val timerRepository: TimerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TasksUiState())
    val uiState: StateFlow<TasksUiState> = _uiState.asStateFlow()

    init {
        loadTasks()
    }

    private fun loadTasks() {
        viewModelScope.launch {
            taskRepository.getAllTasks().collect { tasks ->
                _uiState.update { current ->
                    current.copy(
                        tasks = tasks,
                        filteredTasks = applyFilter(tasks, current.selectedFilter)
                    )
                }
            }
        }
    }

    fun setFilter(filter: String) {
        _uiState.update { current ->
            current.copy(
                selectedFilter = filter,
                filteredTasks = applyFilter(current.tasks, filter)
            )
        }
    }

    private fun applyFilter(tasks: List<TaskEntity>, filter: String): List<TaskEntity> {
        return when (filter) {
            "WORK" -> tasks.filter { it.category == "WORK" }
            "STUDY" -> tasks.filter { it.category == "STUDY" }
            "PROJECT" -> tasks.filter { it.category == "PROJECT" }
            "COMPLETED" -> tasks.filter { it.status == "COMPLETED" }
            "PENDING" -> tasks.filter { it.status != "COMPLETED" }
            else -> tasks
        }
    }

    fun openAddTask() {
        _uiState.update { it.copy(selectedTaskForEdit = null, showAddEditDialog = true) }
    }

    fun openEditTask(task: TaskEntity) {
        _uiState.update { it.copy(selectedTaskForEdit = task, showAddEditDialog = true) }
    }

    fun closeAddEditDialog() {
        _uiState.update { it.copy(showAddEditDialog = false, selectedTaskForEdit = null) }
    }

    fun promptDelete(task: TaskEntity) {
        _uiState.update { it.copy(taskToDelete = task) }
    }

    fun dismissDelete() {
        _uiState.update { it.copy(taskToDelete = null) }
    }

    fun confirmDelete() {
        val task = _uiState.value.taskToDelete ?: return
        viewModelScope.launch {
            taskRepository.deleteTask(task)
            dismissDelete()
        }
    }

    fun saveTask(
        id: Long = 0,
        title: String,
        description: String,
        category: String,
        priority: String,
        dueDate: String,
        dueTime: String,
        durationMinutes: Int,
        notes: String
    ) {
        viewModelScope.launch {
            val task = TaskEntity(
                id = id,
                title = title,
                description = description,
                category = category,
                priority = priority,
                dueDate = dueDate,
                dueTime = dueTime,
                estimatedDurationMinutes = durationMinutes,
                notes = notes,
                status = if (id != 0L) (_uiState.value.selectedTaskForEdit?.status ?: "PENDING") else "PENDING"
            )
            if (id == 0L) {
                taskRepository.insertTask(task)
            } else {
                taskRepository.updateTask(task)
            }
            closeAddEditDialog()
        }
    }

    fun toggleTaskStatus(task: TaskEntity) {
        viewModelScope.launch {
            val newStatus = if (task.status == "COMPLETED") "PENDING" else "COMPLETED"
            val completedAt = if (newStatus == "COMPLETED") System.currentTimeMillis() else null
            taskRepository.updateTask(task.copy(status = newStatus, completedAt = completedAt))
        }
    }

    fun startFocusTimer(task: TaskEntity) {
        viewModelScope.launch {
            timerRepository.startTimer(
                activityId = task.id,
                activityType = "TASK",
                activityTitle = task.title,
                durationMinutes = task.estimatedDurationMinutes
            )
        }
    }
}
