package com.example.ui.screens.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.ui.components.ImageStorageHelper
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import java.io.File

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val preferences by viewModel.preferences.collectAsStateWithLifecycle()

    var customDisplayName by remember(preferences.appDisplayName) {
        mutableStateOf(preferences.appDisplayName)
    }
    var pendingLogoUri by remember(preferences.customLogoUri) {
        mutableStateOf(preferences.customLogoUri)
    }
    var showSavedSnackbar by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val localPath = ImageStorageHelper.saveImageLocally(context, uri, "logo")
            if (localPath != null) {
                pendingLogoUri = localPath
            }
        }
    }

    Scaffold(
        snackbarHost = {
            if (showSavedSnackbar) {
                Snackbar(
                    modifier = Modifier.padding(16.dp),
                    action = {
                        TextButton(onClick = { showSavedSnackbar = false }) {
                            Text("حسناً", color = PrimaryLimeGreen)
                        }
                    }
                ) {
                    Text("تم حفظ التغييرات بنجاح!")
                }
            }
        },
        modifier = modifier
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .testTag("settings_screen"),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. App Identity Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Badge, contentDescription = null, tint = PrimaryLimeGreen)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.appIdentityTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(Modifier.height(14.dp))

                        // Live Preview Box
                        Text(
                            text = strings.previewIdentity,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MainCharcoal,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.5.dp, PrimaryLimeGreen, RoundedCornerShape(12.dp))
                                        .background(DeepDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (!pendingLogoUri.isNullOrBlank() && File(pendingLogoUri!!).exists()) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data(File(pendingLogoUri!!))
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        val logoRes = if (preferences.selectedIconVariant == "light") {
                                            R.drawable.engaz_logo_light
                                        } else {
                                            R.drawable.engaz_logo_dark
                                        }
                                        Image(
                                            painter = painterResource(id = logoRes),
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }

                                Spacer(Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = customDisplayName.ifBlank { "إنجاز" },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = LightGray
                                    )
                                    Text(
                                        text = "معاينة شريط التطبيق العلوي",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = LightGray.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(16.dp))

                        // Name input
                        OutlinedTextField(
                            value = customDisplayName,
                            onValueChange = { customDisplayName = it },
                            label = { Text(strings.appDisplayName) },
                            modifier = Modifier.fillMaxWidth().testTag("app_display_name_input")
                        )

                        Spacer(Modifier.height(12.dp))

                        // Custom Logo Picker
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (pendingLogoUri == null) strings.selectCustomLogo else strings.changeLogo)
                            }

                            if (!pendingLogoUri.isNullOrBlank()) {
                                OutlinedButton(
                                    onClick = { pendingLogoUri = null },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("إزالة", color = StatusError)
                                }
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        // Save & Restore buttons
                        Button(
                            onClick = {
                                viewModel.updateIdentity(customDisplayName.trim(), pendingLogoUri)
                                showSavedSnackbar = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryLimeGreen),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("save_identity_btn")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.save)
                        }

                        Spacer(Modifier.height(8.dp))

                        TextButton(
                            onClick = {
                                viewModel.restoreDefaultIdentity()
                                customDisplayName = "إنجاز"
                                pendingLogoUri = null
                                showSavedSnackbar = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(strings.restoreDefaultIdentity, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        }
                    }
                }
            }

            // 2. Default Brand Logo Mode
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ColorLens, contentDescription = null, tint = PrimaryLimeGreen)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.iconVariant,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = preferences.selectedIconVariant == "dark",
                                onClick = { viewModel.updateIconVariant("dark") },
                                label = { Text(strings.darkIconVariant) }
                            )
                            FilterChip(
                                selected = preferences.selectedIconVariant == "light",
                                onClick = { viewModel.updateIconVariant("light") },
                                label = { Text(strings.lightIconVariant) }
                            )
                        }
                    }
                }
            }

            // 3. Language & Theme
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = PrimaryLimeGreen)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.languageSetting,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = preferences.language == "ar",
                                onClick = { viewModel.updateLanguage("ar") },
                                label = { Text("العربية (RTL)", fontWeight = FontWeight.Bold) }
                            )
                            FilterChip(
                                selected = preferences.language == "en",
                                onClick = { viewModel.updateLanguage("en") },
                                label = { Text("English (LTR)", fontWeight = FontWeight.Bold) }
                            )
                        }

                        Spacer(Modifier.height(16.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = PrimaryLimeGreen)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.themeSetting,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = preferences.themeMode == "dark",
                                onClick = { viewModel.updateTheme("dark") },
                                label = { Text(strings.darkTheme) }
                            )
                            FilterChip(
                                selected = preferences.themeMode == "light",
                                onClick = { viewModel.updateTheme("light") },
                                label = { Text(strings.lightTheme) }
                            )
                        }
                    }
                }
            }

            // 4. Currency Setting
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Payments, contentDescription = null, tint = PrimaryLimeGreen)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "عملة الميزانية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("EGP", "SAR", "USD", "AED", "KWD").forEach { curr ->
                                FilterChip(
                                    selected = preferences.currencySymbol == curr,
                                    onClick = { viewModel.updateCurrency(curr) },
                                    label = { Text(curr, fontWeight = FontWeight.Bold) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
