package com.example.ui.screens.gaming

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.GameEntity
import com.example.ui.components.ImageStorageHelper
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import java.io.File

@Composable
fun GamingScreen(
    viewModel: GamingViewModel,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddGame() },
                containerColor = PrimaryLimeGreen,
                contentColor = NearBlack,
                modifier = Modifier.testTag("add_game_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = strings.addGame)
            }
        },
        modifier = modifier
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Balance & Analytics Card
            item {
                GamingAnalyticsCard(
                    minutesToday = uiState.totalMinutesToday,
                    note = strings.gamingBalanceNote
                )
            }

            // 2. Games Library Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مكتبة الألعاب والترويح",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${uiState.games.size} ألعاب",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            // 3. Games List
            if (uiState.games.isEmpty()) {
                item {
                    GamingEmptyState()
                }
            } else {
                items(uiState.games, key = { it.id }) { game ->
                    GameCard(
                        game = game,
                        onStartSession = { viewModel.openStartSession(game) },
                        onDelete = { viewModel.promptDeleteGame(game) }
                    )
                }
            }
        }

        // Add Game Dialog
        if (uiState.showAddGameDialog) {
            AddGameDialog(
                onDismiss = { viewModel.closeAddGame() },
                onSave = { name, thumb -> viewModel.addGame(name, thumb) }
            )
        }

        // Session Duration Dialog
        if (uiState.showSessionDurationDialog && uiState.selectedGameForSession != null) {
            SelectSessionDurationDialog(
                game = uiState.selectedGameForSession!!,
                onDismiss = { viewModel.closeSessionDurationDialog() },
                onStart = { duration -> viewModel.startSession(uiState.selectedGameForSession!!, duration) }
            )
        }

        // Delete Confirmation
        if (uiState.gameToDelete != null) {
            AlertDialog(
                onDismissRequest = { viewModel.dismissDeleteGame() },
                title = { Text(strings.confirmDelete) },
                text = { Text(strings.confirmDeleteMsg) },
                confirmButton = {
                    Button(
                        onClick = { viewModel.confirmDeleteGame() },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                    ) {
                        Text(strings.delete)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissDeleteGame() }) {
                        Text(strings.cancel)
                    }
                }
            )
        }
    }
}

@Composable
fun GamingAnalyticsCard(minutesToday: Int, note: String) {
    val hours = minutesToday / 60
    val mins = minutesToday % 60
    val timeFormatted = if (hours > 0) "$hours ساعة و $mins دقيقة" else "$mins دقيقة"

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MainCharcoal,
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PrimaryLimeGreen.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = PrimaryLimeGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "وقت الترويح اليوم",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = LightGray
                        )
                        Text(
                            text = timeFormatted,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Black,
                            color = SecondaryLimeYellow
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DeepDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = null,
                        tint = SecondaryLimeYellow,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = note,
                        style = MaterialTheme.typography.bodySmall,
                        color = LightGray.copy(alpha = 0.9f)
                    )
                }
            }
        }
    }
}

@Composable
fun GameCard(
    game: GameEntity,
    onStartSession: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val totalHours = game.totalMinutesPlayed / 60
    val totalMins = game.totalMinutesPlayed % 60

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(18.dp)),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!game.thumbnailUri.isNullOrBlank() && File(game.thumbnailUri).exists()) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(File(game.thumbnailUri))
                        .crossfade(true)
                        .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            } else {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PrimaryLimeGreen.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Gamepad,
                        contentDescription = null,
                        tint = PrimaryLimeGreen,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = game.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "الإجمالي: $totalHours س و $totalMins د",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            Button(
                onClick = onStartSession,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryLimeGreen),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(strings.start)
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = StatusError)
            }
        }
    }
}

@Composable
fun SelectSessionDurationDialog(
    game: GameEntity,
    onDismiss: () -> Unit,
    onStart: (Int) -> Unit
) {
    val strings = LocalAppStrings.current
    var customDurationStr by remember { mutableStateOf("30") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بدء جلسة لعب: ${game.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(strings.chooseDurationMinutes, style = MaterialTheme.typography.bodyMedium)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(15, 30, 45, 60).forEach { mins ->
                        FilledTonalButton(
                            onClick = { onStart(mins) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("$mins د")
                        }
                    }
                }

                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = customDurationStr,
                    onValueChange = { customDurationStr = it },
                    label = { Text("أو أدخل مدة مخصصة (دقيقة)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val mins = customDurationStr.toIntOrNull() ?: 30
                    if (mins > 0) onStart(mins)
                }
            ) {
                Text(strings.start)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
fun AddGameDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, thumb: String?) -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    var name by remember { mutableStateOf("") }
    var thumbnailUri by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val saved = ImageStorageHelper.saveImageLocally(context, uri, "game")
            if (saved != null) thumbnailUri = saved
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.addGame) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(strings.gameName) },
                    modifier = Modifier.fillMaxWidth().testTag("game_name_input")
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("غلاف اللعبة:", style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(
                        onClick = {
                            photoPicker.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        }
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (thumbnailUri == null) "اختيار صورة" else "تغيير")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name.trim(), thumbnailUri)
                    }
                }
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
fun GamingEmptyState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = PrimaryLimeGreen.copy(alpha = 0.5f), modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(8.dp))
        Text(text = "مكتبة الترويح فارغة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            text = "أضف ألعابك المفضلة لتنظيم وقت فراغك بمؤقتات وجلسات واعية ومتوازنة.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
