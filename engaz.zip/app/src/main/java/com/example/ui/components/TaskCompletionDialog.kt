package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HighlightOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.PrimaryLimeGreen
import com.example.ui.theme.StatusSuccess

@Composable
fun TaskCompletionDialog(
    taskTitle: String,
    onDismiss: () -> Unit,
    onCompleted: () -> Unit,
    onIncompleteWithReason: (reason: String) -> Unit
) {
    val strings = LocalAppStrings.current
    var showReasonSelector by remember { mutableStateOf(false) }
    var selectedReason by remember { mutableStateOf(strings.reasonLackOfTime) }
    var customReasonText by remember { mutableStateOf("") }
    var showSuccessMessage by remember { mutableStateOf(false) }

    if (showSuccessMessage) {
        AlertDialog(
            onDismissRequest = {
                showSuccessMessage = false
                onCompleted()
            },
            icon = {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = StatusSuccess,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = { Text(strings.completed, style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.motivationalCongrats, style = MaterialTheme.typography.bodyLarge)
                    Text(strings.motivationalStreak, style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessMessage = false
                        onCompleted()
                    },
                    modifier = Modifier.testTag("dialog_confirm_success")
                ) {
                    Text(strings.save)
                }
            }
        )
    } else if (!showReasonSelector) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(taskTitle, style = MaterialTheme.typography.titleLarge) },
            text = {
                Text(
                    strings.didYouCompleteTask,
                    style = MaterialTheme.typography.bodyLarge
                )
            },
            confirmButton = {
                Button(
                    onClick = { showSuccessMessage = true },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLimeGreen),
                    modifier = Modifier.testTag("task_complete_yes")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(strings.yesCompleted)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showReasonSelector = true },
                    modifier = Modifier.testTag("task_complete_no")
                ) {
                    Icon(Icons.Default.HighlightOff, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(strings.notCompleted)
                }
            }
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(strings.selectReasonPrompt, style = MaterialTheme.typography.titleMedium) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val reasons = listOf(
                        strings.reasonLackOfTime,
                        strings.reasonPostponement,
                        strings.reasonLackOfPrep,
                        strings.reasonOther
                    )

                    reasons.forEach { reason ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(
                                    selected = (selectedReason == reason),
                                    onClick = { selectedReason = reason }
                                )
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = (selectedReason == reason),
                                onClick = { selectedReason = reason }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(reason, style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    if (selectedReason == strings.reasonOther) {
                        OutlinedTextField(
                            value = customReasonText,
                            onValueChange = { customReasonText = it },
                            placeholder = { Text(strings.writeCustomReason) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_reason_input")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalReason = if (selectedReason == strings.reasonOther && customReasonText.isNotBlank()) {
                            customReasonText.trim()
                        } else {
                            selectedReason
                        }
                        onIncompleteWithReason(finalReason)
                    },
                    modifier = Modifier.testTag("save_reason_button")
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text(strings.cancel)
                }
            }
        )
    }
}
