package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryLimeGreen,
    onPrimary = NearBlack,
    primaryContainer = MainCharcoal,
    onPrimaryContainer = PrimaryLimeGreen,
    secondary = SecondaryLimeYellow,
    onSecondary = NearBlack,
    secondaryContainer = DarkCardSurface,
    onSecondaryContainer = SecondaryLimeYellow,
    background = DeepDark,
    onBackground = LightGray,
    surface = DarkCardSurface,
    onSurface = LightGray,
    surfaceVariant = MainCharcoal,
    onSurfaceVariant = LightGray,
    outline = DarkCardBorder,
    outlineVariant = DeepDark,
    error = StatusError,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryLimeGreen,
    onPrimary = NearBlack,
    primaryContainer = LightGray,
    onPrimaryContainer = MainCharcoal,
    secondary = MainCharcoal,
    onSecondary = Color.White,
    secondaryContainer = LightCardBorder,
    onSecondaryContainer = MainCharcoal,
    background = LightBackground,
    onBackground = NearBlack,
    surface = LightCardSurface,
    onSurface = NearBlack,
    surfaceVariant = LightGray,
    onSurfaceVariant = MainCharcoal,
    outline = LightCardBorder,
    outlineVariant = LightGray,
    error = StatusError,
    onError = Color.White
)

@Composable
fun EngazTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    EngazTheme(darkTheme = darkTheme, content = content)
}

