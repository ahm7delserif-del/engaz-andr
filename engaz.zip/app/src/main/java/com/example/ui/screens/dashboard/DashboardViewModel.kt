package com.example.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.*
import com.example.data.repository.*
import com.example.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardItem(
    val id: Long,
    val type: String, // TASK, HABIT, WORKOUT, FASTING
    val title: String,
    val subtitle: String,
    val time: String,
    val durationMinutes: Int,
    val status: String, // COMPLETED, PARTIAL, MISSED, POSTPONED, OVERDUE, PENDING
    val priority: String = "MEDIUM",
    val thumbnailUri: String? = null,
    val reason: String? = null
)

data class DashboardUiState(
    val dateString: String = DateUtils.getTodayDateString(),
    val items: List<DashboardItem> = emptyList(),
    val completionPercentage: Int = 0,
    val completedCount: Int = 0,
    val totalCount: Int = 0,
    val topItemsSummary: String = "",
    val activeTimer: ActiveTimerEntity? = null,
    val selectedItemForCompletion: DashboardItem? = null
)

class DashboardViewModel(
    private val taskRepository: TaskRepository,
    private val habitRepository: HabitRepository,
    private val healthRepository: HealthRepository,
    private val timerRepository: TimerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboardData()
    }

    private fun loadDashboardData() {
        val today = DateUtils.getTodayDateString()

        viewModelScope.launch {
            combine(
                taskRepository.getAllTasks(),
                combine(
                    habitRepository.getAllHabits(),
                    habitRepository.getLogsForDate(today),
                    healthRepository.getWorkoutsForDate(today)
                ) { habits, habitLogs, workouts ->
                    Triple(habits, habitLogs, workouts)
                },
                healthRepository.getFastingPlanForDate(today),
                timerRepository.activeTimerFlow
            ) { tasks, (habits, habitLogs, workouts), fastingPlan, activeTimer ->
                val dashboardItems = mutableListOf<DashboardItem>()

                // 1. Tasks scheduled for today or pending
                tasks.filter { it.dueDate == today || (it.dueDate < today && it.status != "COMPLETED") }.forEach { task ->
                    val isOverdue = task.dueDate < today && task.status != "COMPLETED"
                    val finalStatus = if (isOverdue && task.status != "POSTPONED") "OVERDUE" else task.status
                    dashboardItems.add(
                        DashboardItem(
                            id = task.id,
                            type = "TASK",
                            title = task.title,
                            subtitle = if (task.description.isBlank()) "مهمة عمل / دراسة" else task.description,
                            time = task.dueTime,
                            durationMinutes = task.estimatedDurationMinutes,
                            status = finalStatus,
                            priority = task.priority,
                            thumbnailUri = task.thumbnailUri,
                            reason = task.completionReason
                        )
                    )
                }

                // 2. Habits scheduled for today
                habits.forEach { habit ->
                    if (DateUtils.isHabitScheduledForDate(
                            habit.recurrenceType,
                            habit.recurrenceDays,
                            habit.startDate,
                            habit.endDate,
                            today
                        )
                    ) {
                        val log = habitLogs.find { it.habitId == habit.id }
                        val habitStatus = log?.status ?: "PENDING"
                        val habitSubtitle = if (habit.targetNumeric > 0) {
                            "الهدف: ${habit.targetNumeric.toInt()} ${habit.targetUnit} (تم: ${log?.progressValue?.toInt() ?: 0})"
                        } else if (habit.description.isBlank()) "عادة فكرية" else habit.description

                        dashboardItems.add(
                            DashboardItem(
                                id = habit.id,
                                type = "HABIT",
                                title = habit.title,
                                subtitle = habitSubtitle,
                                time = habit.time,
                                durationMinutes = habit.durationMinutes,
                                status = habitStatus,
                                priority = "HIGH",
                                thumbnailUri = habit.thumbnailUri,
                                reason = log?.incompleteReason
                            )
                        )
                    }
                }

                // 3. Workouts for today
                workouts.forEach { workout ->
                    dashboardItems.add(
                        DashboardItem(
                            id = workout.id,
                            type = "WORKOUT",
                            title = workout.title,
                            subtitle = if (workout.description.isBlank()) "تمرين بدني مجدول" else workout.description,
                            time = workout.time,
                            durationMinutes = workout.durationMinutes,
                            status = workout.status,
                            priority = "MEDIUM",
                            thumbnailUri = workout.thumbnailUri,
                            reason = workout.incompleteReason
                        )
                    )
                }

                // 4. Fasting for today
                if (fastingPlan != null) {
                    val fastingStatus = when (fastingPlan.status) {
                        "COMPLETED" -> "COMPLETED"
                        "BROKEN" -> "MISSED"
                        else -> "PENDING"
                    }
                    dashboardItems.add(
                        DashboardItem(
                            id = fastingPlan.id,
                            type = "FASTING",
                            title = if (fastingPlan.type == "SUNNAH_MON_THU") "صيام الإثنين والخميس" else "صيام يوم مخصص",
                            subtitle = if (fastingPlan.notes.isBlank()) "برنامج صيام صحي" else fastingPlan.notes,
                            time = "الفجر - المغرب",
                            durationMinutes = 0,
                            status = fastingStatus,
                            priority = "HIGH"
                        )
                    )
                }

                // Sort items: High priority and pending first, then by time
                dashboardItems.sortBy { it.time }

                val completedCount = dashboardItems.count { it.status == "COMPLETED" }
                val totalCount = dashboardItems.size
                val percentage = if (totalCount > 0) (completedCount * 100) / totalCount else 0

                val summary = if (dashboardItems.isNotEmpty()) {
                    val top = dashboardItems.filter { it.status != "COMPLETED" }.take(3).joinToString(" • ") { it.title }
                    if (top.isNotBlank()) top else "أكملت جميع مهام اليوم بنجاح!"
                } else {
                    "لا توجد أنشطة مجدولة لليوم."
                }

                DashboardUiState(
                    dateString = today,
                    items = dashboardItems,
                    completionPercentage = percentage,
                    completedCount = completedCount,
                    totalCount = totalCount,
                    topItemsSummary = summary,
                    activeTimer = activeTimer
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun startTimerForActivity(item: DashboardItem) {
        val duration = if (item.durationMinutes > 0) item.durationMinutes else 25
        viewModelScope.launch {
            timerRepository.startTimer(
                activityId = item.id,
                activityType = item.type,
                activityTitle = item.title,
                durationMinutes = duration
            )
        }
    }

    fun stopActiveTimer() {
        viewModelScope.launch {
            timerRepository.clearActiveTimer()
        }
    }

    fun promptCompleteActivity(item: DashboardItem) {
        _uiState.update { it.copy(selectedItemForCompletion = item) }
    }

    fun dismissCompletionDialog() {
        _uiState.update { it.copy(selectedItemForCompletion = null) }
    }

    fun markItemCompleted(item: DashboardItem) {
        viewModelScope.launch {
            val today = DateUtils.getTodayDateString()
            when (item.type) {
                "TASK" -> {
                    val task = taskRepository.getAllTasks().first().find { it.id == item.id }
                    if (task != null) {
                        taskRepository.updateTask(task.copy(status = "COMPLETED", completedAt = System.currentTimeMillis()))
                    }
                }
                "HABIT" -> {
                    val habit = habitRepository.getAllHabits().first().find { it.id == item.id }
                    habitRepository.logHabitProgress(
                        HabitLogEntity(
                            habitId = item.id,
                            date = today,
                            status = "COMPLETED",
                            progressValue = habit?.targetNumeric ?: 1f,
                            timestamp = System.currentTimeMillis()
                        )
                    )
                    if (habit != null) {
                        habitRepository.updateHabit(habit.copy(streak = habit.streak + 1))
                    }
                }
                "WORKOUT" -> {
                    val workout = healthRepository.getAllWorkouts().first().find { it.id == item.id }
                    if (workout != null) {
                        healthRepository.updateWorkout(workout.copy(status = "COMPLETED", completedAt = System.currentTimeMillis()))
                    }
                }
                "FASTING" -> {
                    val fasting = healthRepository.getAllFastingPlans().first().find { it.id == item.id }
                    if (fasting != null) {
                        healthRepository.updateFastingPlan(fasting.copy(status = "COMPLETED"))
                    }
                }
            }
            timerRepository.clearActiveTimer()
            dismissCompletionDialog()
        }
    }

    fun markItemIncompleteWithReason(item: DashboardItem, reason: String) {
        viewModelScope.launch {
            val today = DateUtils.getTodayDateString()
            when (item.type) {
                "TASK" -> {
                    val task = taskRepository.getAllTasks().first().find { it.id == item.id }
                    if (task != null) {
                        taskRepository.updateTask(task.copy(status = "POSTPONED", completionReason = reason))
                    }
                }
                "HABIT" -> {
                    habitRepository.logHabitProgress(
                        HabitLogEntity(
                            habitId = item.id,
                            date = today,
                            status = "MISSED",
                            incompleteReason = reason,
                            timestamp = System.currentTimeMillis()
                        )
                    )
                }
                "WORKOUT" -> {
                    val workout = healthRepository.getAllWorkouts().first().find { it.id == item.id }
                    if (workout != null) {
                        healthRepository.updateWorkout(workout.copy(status = "MISSED", incompleteReason = reason))
                    }
                }
                "FASTING" -> {
                    val fasting = healthRepository.getAllFastingPlans().first().find { it.id == item.id }
                    if (fasting != null) {
                        healthRepository.updateFastingPlan(fasting.copy(status = "BROKEN", notes = reason))
                    }
                }
            }
            timerRepository.clearActiveTimer()
            dismissCompletionDialog()
        }
    }
}
