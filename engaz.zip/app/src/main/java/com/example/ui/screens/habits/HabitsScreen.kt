package com.example.ui.screens.habits

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.HabitEntity
import com.example.ui.components.ImageStorageHelper
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import java.io.File

@Composable
fun HabitsScreen(
    viewModel: HabitsViewModel,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddHabit() },
                containerColor = PrimaryLimeGreen,
                contentColor = NearBlack,
                modifier = Modifier.testTag("add_habit_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = strings.addHabit)
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            if (uiState.habits.isEmpty()) {
                HabitsEmptyState()
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.habits, key = { it.habit.id }) { item ->
                        HabitCard(
                            item = item,
                            onStartTimer = { viewModel.startHabitTimer(item.habit) },
                            onLogProgress = { viewModel.openLogProgress(item.habit) },
                            onEdit = { viewModel.openEditHabit(item.habit) },
                            onDelete = { viewModel.promptDelete(item.habit) }
                        )
                    }
                }
            }

            // Add/Edit Dialog
            if (uiState.showAddEditDialog) {
                AddEditHabitDialog(
                    habit = uiState.selectedHabitForEdit,
                    onDismiss = { viewModel.closeAddEditDialog() },
                    onSave = { id, title, desc, cat, recType, recDays, sDate, eDate, time, dur, target, unit, thumb ->
                        viewModel.saveHabit(
                            id = id,
                            title = title,
                            description = desc,
                            category = cat,
                            recurrenceType = recType,
                            recurrenceDays = recDays,
                            startDate = sDate,
                            endDate = eDate,
                            time = time,
                            durationMinutes = dur,
                            targetNumeric = target,
                            targetUnit = unit,
                            thumbnailUri = thumb
                        )
                    }
                )
            }

            // Log Progress Dialog
            if (uiState.showLogDialog && uiState.selectedHabitForLogging != null) {
                LogHabitProgressDialog(
                    habit = uiState.selectedHabitForLogging!!,
                    onDismiss = { viewModel.closeLogDialog() },
                    onSave = { value, status, notes, reason ->
                        viewModel.logProgress(uiState.selectedHabitForLogging!!, value, status, notes, reason)
                    }
                )
            }

            // Delete Confirmation Dialog
            if (uiState.habitToDelete != null) {
                AlertDialog(
                    onDismissRequest = { viewModel.dismissDeletePrompt() },
                    title = { Text(strings.confirmDelete) },
                    text = { Text(strings.confirmDeleteMsg) },
                    confirmButton = {
                        Button(
                            onClick = { viewModel.confirmDelete() },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                        ) {
                            Text(strings.delete)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { viewModel.dismissDeletePrompt() }) {
                            Text(strings.cancel)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun HabitCard(
    item: HabitWithTodayStatus,
    onStartTimer: () -> Unit,
    onLogProgress: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val habit = item.habit
    val todayLog = item.todayLog

    val isCompletedToday = todayLog?.status == "COMPLETED"
    val progressValue = todayLog?.progressValue ?: 0f
    val target = habit.targetNumeric.coerceAtLeast(1f)
    val progressFraction = (progressValue / target).coerceIn(0f, 1f)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(
                1.dp,
                if (isCompletedToday) StatusSuccess.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                RoundedCornerShape(20.dp)
            ),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Thumbnail
                if (!habit.thumbnailUri.isNullOrBlank() && File(habit.thumbnailUri).exists()) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(File(habit.thumbnailUri))
                            .crossfade(true)
                            .build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(14.dp))
                    )
                } else {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(PrimaryLimeGreen.copy(alpha = 0.15f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = PrimaryLimeGreen,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = habit.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (habit.description.isNotBlank()) {
                        Text(
                            text = habit.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            maxLines = 1
                        )
                    }

                    Spacer(Modifier.height(4.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Streak badge
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SecondaryLimeYellow.copy(alpha = 0.2f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🔥", style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.width(2.dp))
                                Text(
                                    text = "${habit.streak} ${strings.days}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (MaterialTheme.colorScheme.background == DeepDark) LightGray else NearBlack,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Time badge
                        Text(
                            text = habit.time,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }

                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = strings.edit, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = strings.delete, tint = StatusError)
                }
            }

            Spacer(Modifier.height(12.dp))

            // Numeric Goal & Progress bar
            if (habit.targetNumeric > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${progressValue.toInt()} / ${habit.targetNumeric.toInt()} ${habit.targetUnit}",
                        style = MaterialTheme.typography.labelMedium,
                        color = PrimaryLimeGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${(progressFraction * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = PrimaryLimeGreen,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            Spacer(Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onStartTimer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("${strings.start} (${habit.durationMinutes} د)")
                }

                Button(
                    onClick = onLogProgress,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCompletedToday) StatusSuccess else PrimaryLimeGreen
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(if (isCompletedToday) Icons.Default.Check else Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (isCompletedToday) strings.completed else strings.logProgress)
                }
            }
        }
    }
}

@Composable
fun AddEditHabitDialog(
    habit: HabitEntity?,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        title: String,
        description: String,
        category: String,
        recurrenceType: String,
        recurrenceDays: String,
        startDate: String?,
        endDate: String?,
        time: String,
        durationMinutes: Int,
        targetNumeric: Float,
        targetUnit: String,
        thumbnailUri: String?
    ) -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    var title by remember { mutableStateOf(habit?.title ?: "") }
    var description by remember { mutableStateOf(habit?.description ?: "") }
    var recurrenceType by remember { mutableStateOf(habit?.recurrenceType ?: "DAILY") }
    var recurrenceDays by remember { mutableStateOf(habit?.recurrenceDays ?: "MON,TUE,WED,THU,FRI,SAT,SUN") }
    var time by remember { mutableStateOf(habit?.time ?: "08:00") }
    var durationMinutesStr by remember { mutableStateOf(habit?.durationMinutes?.toString() ?: "20") }
    var targetNumericStr by remember { mutableStateOf(habit?.targetNumeric?.toInt()?.toString() ?: "20") }
    var targetUnit by remember { mutableStateOf(habit?.targetUnit ?: strings.pages) }
    var thumbnailUri by remember { mutableStateOf(habit?.thumbnailUri) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = ImageStorageHelper.saveImageLocally(context, uri, "habit")
            if (savedPath != null) {
                thumbnailUri = savedPath
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (habit == null) strings.addHabit else strings.edit) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(strings.habitTitle) },
                        modifier = Modifier.fillMaxWidth().testTag("habit_title_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text(strings.habitDescription) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Thumbnail selection
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("الصورة التعبيرية:", style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!thumbnailUri.isNullOrBlank()) {
                                AsyncImage(
                                    model = File(thumbnailUri!!),
                                    contentDescription = null,
                                    modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                TextButton(onClick = { thumbnailUri = null }) {
                                    Text("إزالة", color = StatusError)
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                }
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (thumbnailUri == null) "اختيار صورة" else "تغيير")
                            }
                        }
                    }
                }

                // Recurrence
                item {
                    Text(strings.habitRecurrence, style = MaterialTheme.typography.labelMedium)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        FilterChip(
                            selected = recurrenceType == "DAILY",
                            onClick = { recurrenceType = "DAILY" },
                            label = { Text(strings.dailyRecurrence) }
                        )
                        FilterChip(
                            selected = recurrenceType == "WEEKDAYS",
                            onClick = { recurrenceType = "WEEKDAYS" },
                            label = { Text("أيام الأسبوع") }
                        )
                    }
                }

                // Numeric Goal & Unit
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = targetNumericStr,
                            onValueChange = { targetNumericStr = it },
                            label = { Text(strings.targetNumeric) },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = targetUnit,
                            onValueChange = { targetUnit = it },
                            label = { Text(strings.targetUnit) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Time & Duration
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = time,
                            onValueChange = { time = it },
                            label = { Text("الوقت (08:00)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = durationMinutesStr,
                            onValueChange = { durationMinutesStr = it },
                            label = { Text("المدة (دقيقة)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val duration = durationMinutesStr.toIntOrNull() ?: 20
                        val target = targetNumericStr.toFloatOrNull() ?: 1f
                        onSave(
                            habit?.id ?: 0L,
                            title.trim(),
                            description.trim(),
                            "MIND",
                            recurrenceType,
                            recurrenceDays,
                            habit?.startDate,
                            habit?.endDate,
                            time.trim(),
                            duration,
                            target,
                            targetUnit.trim(),
                            thumbnailUri
                        )
                    }
                },
                modifier = Modifier.testTag("save_habit_btn")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun LogHabitProgressDialog(
    habit: HabitEntity,
    onDismiss: () -> Unit,
    onSave: (value: Float, status: String, notes: String, reason: String?) -> Unit
) {
    val strings = LocalAppStrings.current
    var progressStr by remember { mutableStateOf(habit.targetNumeric.toInt().toString()) }
    var notes by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("COMPLETED") }
    var reason by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${strings.logProgress}: ${habit.title}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = progressStr,
                    onValueChange = { progressStr = it },
                    label = { Text("الكمية المنجزة (${habit.targetUnit})") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات الفهم أو الإنجاز") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = status == "COMPLETED",
                        onClick = { status = "COMPLETED" },
                        label = { Text(strings.completed) }
                    )
                    FilterChip(
                        selected = status == "PARTIAL",
                        onClick = { status = "PARTIAL" },
                        label = { Text("جزئي") }
                    )
                    FilterChip(
                        selected = status == "MISSED",
                        onClick = { status = "MISSED" },
                        label = { Text(strings.missed) }
                    )
                }

                if (status != "COMPLETED") {
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("سبب عدم الإكمال التام") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val value = progressStr.toFloatOrNull() ?: 0f
                    onSave(value, status, notes.trim(), if (reason.isNotBlank()) reason.trim() else null)
                }
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun HabitsEmptyState() {
    val strings = LocalAppStrings.current
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Psychology,
            contentDescription = null,
            tint = PrimaryLimeGreen.copy(alpha = 0.5f),
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "صحة العقل والعادات",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "أضف أهدافك الفكرية كقراءة الكتب، حفظ القرآن، ودراسة المواد مع متابعة السلاسل والتقدم.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
