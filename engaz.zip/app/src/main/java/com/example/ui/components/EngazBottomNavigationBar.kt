package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.NavRoutes
import com.example.ui.theme.LightGray
import com.example.ui.theme.MainCharcoal
import com.example.ui.theme.PrimaryLimeGreen

data class EngazNavItem(
    val route: String,
    val titleAr: String,
    val titleEn: String,
    val icon: ImageVector
)

val defaultNavItems = listOf(
    EngazNavItem(NavRoutes.DASHBOARD, "اليوم", "Today", Icons.Default.GridView),
    EngazNavItem(NavRoutes.TASKS, "المهام", "Tasks", Icons.Default.Assignment),
    EngazNavItem(NavRoutes.HABITS, "العادات", "Habits", Icons.Default.Psychology),
    EngazNavItem(NavRoutes.HEALTH, "الصحة", "Health", Icons.Default.FitnessCenter),
    EngazNavItem(NavRoutes.FINANCE, "المالية", "Finance", Icons.Default.AccountBalanceWallet),
    EngazNavItem(NavRoutes.GAMING, "الترفيه", "Leisure", Icons.Default.SportsEsports),
    EngazNavItem(NavRoutes.REPORTS, "التقارير", "Reports", Icons.Default.BarChart)
)

@Composable
fun EngazBottomNavigationBar(
    currentRoute: String,
    isArabic: Boolean,
    isDark: Boolean,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
    items: List<EngazNavItem> = defaultNavItems
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val selected = currentRoute == item.route
                val itemLabel = if (isArabic) item.titleAr else item.titleEn
                val contentColor = if (selected) {
                    if (isDark) PrimaryLimeGreen else Color(0xFF628919)
                } else {
                    if (isDark) LightGray.copy(alpha = 0.7f) else MainCharcoal.copy(alpha = 0.8f)
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = false, radius = 26.dp)
                        ) {
                            onNavigate(item.route)
                        }
                        .testTag("nav_${item.route}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = itemLabel,
                            tint = contentColor,
                            modifier = Modifier.size(23.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = itemLabel,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 11.sp,
                                lineHeight = 14.sp,
                                letterSpacing = 0.sp,
                                textAlign = TextAlign.Center,
                                platformStyle = PlatformTextStyle(
                                    includeFontPadding = false
                                )
                            ),
                            color = contentColor,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
