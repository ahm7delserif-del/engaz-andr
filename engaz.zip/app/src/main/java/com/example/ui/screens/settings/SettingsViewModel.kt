package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.datastore.AppPreferences
import com.example.data.datastore.UserPreferencesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    val preferences: StateFlow<AppPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppPreferences()
        )

    fun updateLanguage(lang: String) {
        viewModelScope.launch {
            preferencesRepository.updateLanguage(lang)
        }
    }

    fun updateTheme(themeMode: String) {
        viewModelScope.launch {
            preferencesRepository.updateThemeMode(themeMode)
        }
    }

    fun updateIdentity(displayName: String, logoUri: String?) {
        viewModelScope.launch {
            preferencesRepository.updateAppIdentity(displayName, logoUri)
        }
    }

    fun restoreDefaultIdentity() {
        viewModelScope.launch {
            preferencesRepository.restoreDefaultIdentity()
        }
    }

    fun updateIconVariant(variant: String) {
        viewModelScope.launch {
            preferencesRepository.updateIconVariant(variant)
        }
    }

    fun updateWeeklyReviewDay(day: Int) {
        viewModelScope.launch {
            preferencesRepository.updateWeeklyReviewDay(day)
        }
    }

    fun updateCurrency(symbol: String) {
        viewModelScope.launch {
            preferencesRepository.updateCurrency(symbol)
        }
    }
}
