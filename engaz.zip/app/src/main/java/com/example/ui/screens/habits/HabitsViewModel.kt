package com.example.ui.screens.habits

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.repository.HabitRepository
import com.example.data.repository.TimerRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HabitWithTodayStatus(
    val habit: HabitEntity,
    val todayLog: HabitLogEntity?,
    val isScheduledToday: Boolean
)

data class HabitsUiState(
    val habits: List<HabitWithTodayStatus> = emptyList(),
    val selectedHabitForEdit: HabitEntity? = null,
    val showAddEditDialog: Boolean = false,
    val selectedHabitForLogging: HabitEntity? = null,
    val showLogDialog: Boolean = false,
    val habitToDelete: HabitEntity? = null
)

class HabitsViewModel(
    private val habitRepository: HabitRepository,
    private val timerRepository: TimerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HabitsUiState())
    val uiState: StateFlow<HabitsUiState> = _uiState.asStateFlow()

    init {
        loadHabits()
    }

    private fun loadHabits() {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            combine(
                habitRepository.getAllHabits(),
                habitRepository.getLogsForDate(today)
            ) { habits, logs ->
                val list = habits.map { habit ->
                    val isScheduled = DateUtils.isHabitScheduledForDate(
                        habit.recurrenceType,
                        habit.recurrenceDays,
                        habit.startDate,
                        habit.endDate,
                        today
                    )
                    val log = logs.find { it.habitId == habit.id }
                    HabitWithTodayStatus(
                        habit = habit,
                        todayLog = log,
                        isScheduledToday = isScheduled
                    )
                }
                HabitsUiState(habits = list)
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun openAddHabit() {
        _uiState.update { it.copy(selectedHabitForEdit = null, showAddEditDialog = true) }
    }

    fun openEditHabit(habit: HabitEntity) {
        _uiState.update { it.copy(selectedHabitForEdit = habit, showAddEditDialog = true) }
    }

    fun closeAddEditDialog() {
        _uiState.update { it.copy(showAddEditDialog = false, selectedHabitForEdit = null) }
    }

    fun openLogProgress(habit: HabitEntity) {
        _uiState.update { it.copy(selectedHabitForLogging = habit, showLogDialog = true) }
    }

    fun closeLogDialog() {
        _uiState.update { it.copy(showLogDialog = false, selectedHabitForLogging = null) }
    }

    fun promptDelete(habit: HabitEntity) {
        _uiState.update { it.copy(habitToDelete = habit) }
    }

    fun dismissDeletePrompt() {
        _uiState.update { it.copy(habitToDelete = null) }
    }

    fun confirmDelete() {
        val habit = _uiState.value.habitToDelete ?: return
        viewModelScope.launch {
            habitRepository.deleteHabit(habit)
            _uiState.update { it.copy(habitToDelete = null) }
        }
    }

    fun saveHabit(
        id: Long = 0,
        title: String,
        description: String,
        category: String,
        recurrenceType: String,
        recurrenceDays: String,
        startDate: String?,
        endDate: String?,
        time: String,
        durationMinutes: Int,
        targetNumeric: Float,
        targetUnit: String,
        thumbnailUri: String?
    ) {
        viewModelScope.launch {
            val habit = HabitEntity(
                id = id,
                title = title,
                description = description,
                category = category,
                recurrenceType = recurrenceType,
                recurrenceDays = recurrenceDays,
                startDate = startDate,
                endDate = endDate,
                time = time,
                durationMinutes = durationMinutes,
                targetNumeric = targetNumeric,
                targetUnit = targetUnit,
                thumbnailUri = thumbnailUri
            )
            if (id == 0L) {
                habitRepository.insertHabit(habit)
            } else {
                habitRepository.updateHabit(habit)
            }
            closeAddEditDialog()
        }
    }

    fun logProgress(
        habit: HabitEntity,
        progressValue: Float,
        status: String,
        notes: String,
        incompleteReason: String? = null
    ) {
        viewModelScope.launch {
            val today = DateUtils.getTodayDateString()
            habitRepository.logHabitProgress(
                HabitLogEntity(
                    habitId = habit.id,
                    date = today,
                    status = status,
                    progressValue = progressValue,
                    notes = notes,
                    incompleteReason = incompleteReason,
                    timestamp = System.currentTimeMillis()
                )
            )
            if (status == "COMPLETED") {
                habitRepository.updateHabit(habit.copy(streak = habit.streak + 1))
            }
            closeLogDialog()
        }
    }

    fun startHabitTimer(habit: HabitEntity) {
        viewModelScope.launch {
            timerRepository.startTimer(
                activityId = habit.id,
                activityType = "HABIT",
                activityTitle = habit.title,
                durationMinutes = habit.durationMinutes
            )
        }
    }
}
