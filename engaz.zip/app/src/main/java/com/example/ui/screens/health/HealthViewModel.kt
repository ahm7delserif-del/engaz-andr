package com.example.ui.screens.health

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.FastingPlanEntity
import com.example.data.local.entity.WorkoutEntity
import com.example.data.repository.HealthRepository
import com.example.data.repository.TimerRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HealthUiState(
    val todayWaterMl: Int = 0,
    val waterGoalMl: Int = 3000,
    val todayFastingPlan: FastingPlanEntity? = null,
    val todayWorkouts: List<WorkoutEntity> = emptyList(),
    val allWorkouts: List<WorkoutEntity> = emptyList(),
    val allFastingPlans: List<FastingPlanEntity> = emptyList(),
    val showAddWorkoutDialog: Boolean = false,
    val selectedWorkoutForEdit: WorkoutEntity? = null,
    val workoutToDelete: WorkoutEntity? = null,
    val showFastingDialog: Boolean = false
)

class HealthViewModel(
    private val healthRepository: HealthRepository,
    private val timerRepository: TimerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HealthUiState())
    val uiState: StateFlow<HealthUiState> = _uiState.asStateFlow()

    init {
        loadHealthData()
    }

    private fun loadHealthData() {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            combine(
                healthRepository.getTotalWaterForDate(today),
                healthRepository.getFastingPlanForDate(today),
                healthRepository.getAllWorkouts(),
                healthRepository.getAllFastingPlans()
            ) { waterTotal, fastingPlan, allWorkouts, allFasting ->
                val todayWorkouts = allWorkouts.filter { it.date == today }
                HealthUiState(
                    todayWaterMl = waterTotal ?: 0,
                    waterGoalMl = 3000,
                    todayFastingPlan = fastingPlan,
                    todayWorkouts = todayWorkouts,
                    allWorkouts = allWorkouts,
                    allFastingPlans = allFasting
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun addWater(amountMl: Int) {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            healthRepository.logWater(amountMl, today)
        }
    }

    fun resetWater() {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            healthRepository.clearWaterLogsForDate(today)
        }
    }

    fun setFastingPlanToday(type: String, status: String) {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            val existing = _uiState.value.todayFastingPlan
            if (existing != null) {
                healthRepository.updateFastingPlan(existing.copy(type = type, status = status))
            } else {
                healthRepository.saveFastingPlan(
                    FastingPlanEntity(
                        date = today,
                        type = type,
                        status = status
                    )
                )
            }
            _uiState.update { it.copy(showFastingDialog = false) }
        }
    }

    fun removeFastingToday() {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            healthRepository.deleteFastingPlanForDate(today)
            _uiState.update { it.copy(showFastingDialog = false) }
        }
    }

    fun openAddWorkout() {
        _uiState.update { it.copy(selectedWorkoutForEdit = null, showAddWorkoutDialog = true) }
    }

    fun openEditWorkout(workout: WorkoutEntity) {
        _uiState.update { it.copy(selectedWorkoutForEdit = workout, showAddWorkoutDialog = true) }
    }

    fun closeWorkoutDialog() {
        _uiState.update { it.copy(showAddWorkoutDialog = false, selectedWorkoutForEdit = null) }
    }

    fun promptDeleteWorkout(workout: WorkoutEntity) {
        _uiState.update { it.copy(workoutToDelete = workout) }
    }

    fun dismissDeleteWorkout() {
        _uiState.update { it.copy(workoutToDelete = null) }
    }

    fun confirmDeleteWorkout() {
        val workout = _uiState.value.workoutToDelete ?: return
        viewModelScope.launch {
            healthRepository.deleteWorkout(workout)
            dismissDeleteWorkout()
        }
    }

    fun saveWorkout(
        id: Long = 0,
        title: String,
        description: String,
        date: String,
        time: String,
        durationMinutes: Int,
        thumbnailUri: String?
    ) {
        viewModelScope.launch {
            val workout = WorkoutEntity(
                id = id,
                title = title,
                description = description,
                date = date,
                weekday = DateUtils.getWeekdayNameForDate(date),
                time = time,
                durationMinutes = durationMinutes,
                thumbnailUri = thumbnailUri
            )
            if (id == 0L) {
                healthRepository.insertWorkout(workout)
            } else {
                healthRepository.updateWorkout(workout)
            }
            closeWorkoutDialog()
        }
    }

    fun toggleWorkoutCompleted(workout: WorkoutEntity) {
        viewModelScope.launch {
            val newStatus = if (workout.status == "COMPLETED") "PENDING" else "COMPLETED"
            val completedAt = if (newStatus == "COMPLETED") System.currentTimeMillis() else null
            healthRepository.updateWorkout(workout.copy(status = newStatus, completedAt = completedAt))
        }
    }

    fun startWorkoutTimer(workout: WorkoutEntity) {
        viewModelScope.launch {
            timerRepository.startTimer(
                activityId = workout.id,
                activityType = "WORKOUT",
                activityTitle = workout.title,
                durationMinutes = workout.durationMinutes
            )
        }
    }

    fun openFastingDialog() {
        _uiState.update { it.copy(showFastingDialog = true) }
    }

    fun closeFastingDialog() {
        _uiState.update { it.copy(showFastingDialog = false) }
    }
}
