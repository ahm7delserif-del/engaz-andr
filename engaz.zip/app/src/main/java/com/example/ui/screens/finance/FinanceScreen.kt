package com.example.ui.screens.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.datastore.AppPreferences
import com.example.data.local.entity.FinanceCommitmentEntity
import com.example.data.local.entity.FinanceExpenseEntity
import com.example.data.local.entity.SavingsGoalEntity
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import com.example.util.DateUtils

@Composable
fun FinanceScreen(
    viewModel: FinanceViewModel,
    preferences: AppPreferences,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Expenses, 1: Commitments, 2: Savings

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    when (selectedTab) {
                        0 -> viewModel.openAddExpense()
                        1 -> viewModel.openAddCommitment()
                        2 -> viewModel.openAddGoal()
                    }
                },
                containerColor = PrimaryLimeGreen,
                contentColor = NearBlack,
                modifier = Modifier.testTag("finance_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = strings.add)
            }
        },
        modifier = modifier
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Finance Overview Card
            item {
                FinanceOverviewCard(
                    income = uiState.monthlyIncome,
                    commitments = uiState.totalCommitments,
                    expenses = uiState.totalExpensesThisMonth,
                    remaining = uiState.remainingBalance,
                    isWarning = uiState.isBudgetCloseToLimit,
                    currency = preferences.currencySymbol,
                    onSetIncome = { viewModel.openSetIncome() }
                )
            }

            // 2. Tab Row
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PrimaryLimeGreen,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text(strings.dailyExpenses, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("الالتزامات", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text(strings.savingsGoals, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // 3. Tab Content
            when (selectedTab) {
                0 -> {
                    if (uiState.expenses.isEmpty()) {
                        item { EmptyFinanceSection("لا توجد مصاريف مسجلة هذا الشهر") }
                    } else {
                        items(uiState.expenses, key = { it.id }) { expense ->
                            ExpenseItemRow(
                                expense = expense,
                                currency = preferences.currencySymbol,
                                onDelete = { viewModel.deleteExpense(expense) }
                            )
                        }
                    }
                }
                1 -> {
                    if (uiState.commitments.isEmpty()) {
                        item { EmptyFinanceSection("لا توجد التزامات شهرية ثابتة مسجلة") }
                    } else {
                        items(uiState.commitments, key = { it.id }) { item ->
                            CommitmentItemRow(
                                commitment = item,
                                currency = preferences.currencySymbol,
                                onTogglePaid = { viewModel.toggleCommitmentPaid(item) },
                                onDelete = { viewModel.deleteCommitment(item) }
                            )
                        }
                    }
                }
                2 -> {
                    if (uiState.savingsGoals.isEmpty()) {
                        item { EmptyFinanceSection("لا توجد أهداف ادخار بعد. حدد هدفك المالي الأول!") }
                    } else {
                        items(uiState.savingsGoals, key = { it.id }) { goal ->
                            SavingsGoalCard(
                                goal = goal,
                                currency = preferences.currencySymbol,
                                onAddSavings = { extra -> viewModel.updateSavingsProgress(goal, goal.currentAmount + extra) },
                                onDelete = { viewModel.deleteSavingsGoal(goal) }
                            )
                        }
                    }
                }
            }
        }

        // Dialogs
        if (uiState.showSetIncomeDialog) {
            SetIncomeDialog(
                currentIncome = uiState.monthlyIncome,
                currency = preferences.currencySymbol,
                onDismiss = { viewModel.closeSetIncome() },
                onSave = { viewModel.setMonthlyIncome(it) }
            )
        }

        if (uiState.showAddExpenseDialog) {
            AddExpenseDialog(
                currency = preferences.currencySymbol,
                onDismiss = { viewModel.closeAddExpense() },
                onSave = { title, amount, cat, date, notes -> viewModel.addExpense(title, amount, cat, date, notes) }
            )
        }

        if (uiState.showAddCommitmentDialog) {
            AddCommitmentDialog(
                currency = preferences.currencySymbol,
                onDismiss = { viewModel.closeAddCommitment() },
                onSave = { title, amount, cat, dueDay -> viewModel.addCommitment(title, amount, cat, dueDay) }
            )
        }

        if (uiState.showAddGoalDialog) {
            AddSavingsGoalDialog(
                currency = preferences.currencySymbol,
                onDismiss = { viewModel.closeAddGoal() },
                onSave = { title, target, current, date, notes -> viewModel.addSavingsGoal(title, target, current, date, notes) }
            )
        }
    }
}

@Composable
fun FinanceOverviewCard(
    income: Double,
    commitments: Double,
    expenses: Double,
    remaining: Double,
    isWarning: Boolean,
    currency: String,
    onSetIncome: () -> Unit
) {
    val strings = LocalAppStrings.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MainCharcoal,
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.remainingBalance,
                        style = MaterialTheme.typography.labelMedium,
                        color = LightGray.copy(alpha = 0.7f)
                    )
                    Text(
                        text = String.format("%.2f %s", remaining, currency),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = if (remaining < 0) StatusError else PrimaryLimeGreen
                    )
                }

                TextButton(onClick = onSetIncome) {
                    Icon(Icons.Default.AttachMoney, contentDescription = null, tint = SecondaryLimeYellow)
                    Spacer(Modifier.width(4.dp))
                    Text(if (income == 0.0) strings.setIncome else "تعديل الدخل", color = SecondaryLimeYellow)
                }
            }

            Spacer(Modifier.height(14.dp))

            // Sub-metrics row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FinanceStatPill(
                    title = strings.monthlyIncome,
                    value = String.format("%.0f", income),
                    color = PrimaryLimeGreen
                )
                FinanceStatPill(
                    title = "الالتزامات",
                    value = String.format("%.0f", commitments),
                    color = SecondaryLimeYellow
                )
                FinanceStatPill(
                    title = "المصاريف",
                    value = String.format("%.0f", expenses),
                    color = StatusWarning
                )
            }

            if (isWarning) {
                Spacer(Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StatusWarning.copy(alpha = 0.2f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = StatusWarning)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = strings.budgetExceededWarning,
                            style = MaterialTheme.typography.bodySmall,
                            color = LightGray
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FinanceStatPill(title: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DeepDark)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, style = MaterialTheme.typography.labelSmall, color = LightGray.copy(alpha = 0.6f))
        Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun ExpenseItemRow(
    expense: FinanceExpenseEntity,
    currency: String,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(StatusWarning.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(text = expense.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(text = "${expense.category} • ${expense.date}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = String.format("-%.2f %s", expense.amount, currency),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = StatusError
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                }
            }
        }
    }
}

@Composable
fun CommitmentItemRow(
    commitment: FinanceCommitmentEntity,
    currency: String,
    onTogglePaid: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (commitment.isPaidThisMonth) StatusSuccess.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Checkbox(
                    checked = commitment.isPaidThisMonth,
                    onCheckedChange = { onTogglePaid() }
                )
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(text = commitment.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(text = "تستحق يوم ${commitment.dueDayOfMonth} من الشهر", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = String.format("%.2f %s", commitment.amount, currency),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (commitment.isPaidThisMonth) StatusSuccess else MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                }
            }
        }
    }
}

@Composable
fun SavingsGoalCard(
    goal: SavingsGoalEntity,
    currency: String,
    onAddSavings: (Double) -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val progress = (goal.currentAmount / goal.targetAmount).toFloat().coerceIn(0f, 1f)
    val percentage = (progress * 100).toInt()
    val isNearTarget = percentage >= 85

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isNearTarget) PrimaryLimeGreen.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = goal.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(text = "الهدف: ${goal.targetAmount.toInt()} $currency (حتى ${goal.targetDate})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = StatusError)
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "تم ادخار: ${goal.currentAmount.toInt()} $currency", style = MaterialTheme.typography.labelMedium, color = PrimaryLimeGreen, fontWeight = FontWeight.Bold)
                Text(text = "$percentage%", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = PrimaryLimeGreen,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            if (isNearTarget && percentage < 100) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = strings.savingsNearTargetWarning,
                    style = MaterialTheme.typography.labelSmall,
                    color = SecondaryLimeYellow,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = { onAddSavings(100.0) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("+100")
                }
                FilledTonalButton(
                    onClick = { onAddSavings(500.0) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("+500")
                }
            }
        }
    }
}

@Composable
fun SetIncomeDialog(
    currentIncome: Double,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (Double) -> Unit
) {
    var amountStr by remember { mutableStateOf(if (currentIncome > 0) currentIncome.toInt().toString() else "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تحديد الدخل الشهري") },
        text = {
            OutlinedTextField(
                value = amountStr,
                onValueChange = { amountStr = it },
                label = { Text("المبلغ ($currency)") },
                modifier = Modifier.fillMaxWidth().testTag("income_input")
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    onSave(amount)
                }
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun AddExpenseDialog(
    currency: String,
    onDismiss: () -> Unit,
    onSave: (title: String, amount: Double, cat: String, date: String, notes: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("طعام ومشتريات") }
    var date by remember { mutableStateOf(DateUtils.getTodayDateString()) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مصروف جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("وصف المصروف") },
                    modifier = Modifier.fillMaxWidth().testTag("expense_title_input")
                )
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("المبلغ ($currency)") },
                    modifier = Modifier.fillMaxWidth().testTag("expense_amount_input")
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("التصنيف (طعام، مواصلات، تسوق، صحة)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && amt > 0) {
                        onSave(title.trim(), amt, category.trim(), date.trim(), notes.trim())
                    }
                }
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AddCommitmentDialog(
    currency: String,
    onDismiss: () -> Unit,
    onSave: (title: String, amount: Double, cat: String, dueDay: Int) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var dueDayStr by remember { mutableStateOf("1") }
    var category by remember { mutableStateOf("إيجار وفواتير") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة التزام شهري ثابت") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم الالتزام (إيجار، إنترنت، قسط)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("المبلغ ($currency)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dueDayStr,
                    onValueChange = { dueDayStr = it },
                    label = { Text("يوم الاستحقاق من الشهر (1-31)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    val day = dueDayStr.toIntOrNull() ?: 1
                    if (title.isNotBlank() && amt > 0) {
                        onSave(title.trim(), amt, category.trim(), day)
                    }
                }
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AddSavingsGoalDialog(
    currency: String,
    onDismiss: () -> Unit,
    onSave: (title: String, target: Double, current: Double, date: String, notes: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var targetStr by remember { mutableStateOf("") }
    var currentStr by remember { mutableStateOf("0") }
    var date by remember { mutableStateOf(DateUtils.getTodayDateString()) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة هدف ادخار جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم الهدف (صندوق طوارئ، جهاز جديد)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = targetStr,
                    onValueChange = { targetStr = it },
                    label = { Text("المبلغ المستهدف ($currency)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = currentStr,
                    onValueChange = { currentStr = it },
                    label = { Text("المبلغ الموفر حالياً") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("التاريخ المستهدف (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val target = targetStr.toDoubleOrNull() ?: 0.0
                    val current = currentStr.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && target > 0) {
                        onSave(title.trim(), target, current, date.trim(), notes.trim())
                    }
                }
            ) {
                Text("حفظ الهدف")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun EmptyFinanceSection(message: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = PrimaryLimeGreen.copy(alpha = 0.5f), modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(8.dp))
        Text(text = message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
    }
}
