package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Exact mandatory brand color tokens
val NearBlack = Color(0xFF050605)
val LightGray = Color(0xFFE5E6E5)
val DeepDark = Color(0xFF161E21)
val MainCharcoal = Color(0xFF2C353B)
val PrimaryLimeGreen = Color(0xFF9ECB3F)
val SecondaryLimeYellow = Color(0xFFBED535)

// Surface & Layering tokens
val DarkCardSurface = Color(0xFF1F282D)
val DarkCardBorder = Color(0xFF38434A)
val LightCardSurface = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFD6DAD6)
val LightBackground = Color(0xFFF1F3F1)
val TextSecondaryDark = Color(0xFFA0ABB0)

// Status accents
val StatusSuccess = Color(0xFF9ECB3F)
val StatusWarning = Color(0xFFFFA726)
val StatusError = Color(0xFFEF5350)
val StatusInfo = Color(0xFF29B6F6)

