package com.example.ui.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*

@Composable
fun ReportsScreen(
    viewModel: ReportsViewModel,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("reports_screen"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Period Selector Tabs
        item {
            val periods = listOf(
                "DAILY" to strings.dailyReport,
                "MONTHLY" to strings.monthlyReport,
                "YEARLY" to strings.yearlyReport,
                "WEEKLY_REVIEW" to strings.weeklyReview
            )
            TabRow(
                selectedTabIndex = when (uiState.selectedPeriod) {
                    "MONTHLY" -> 1
                    "YEARLY" -> 2
                    "WEEKLY_REVIEW" -> 3
                    else -> 0
                },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = PrimaryLimeGreen,
                modifier = Modifier.clip(RoundedCornerShape(14.dp))
            ) {
                periods.forEachIndexed { index, (key, label) ->
                    Tab(
                        selected = uiState.selectedPeriod == key,
                        onClick = { viewModel.setPeriod(key) },
                        text = { Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
                    )
                }
            }
        }

        // 2. High-level Performance Hero Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = MainCharcoal,
                tonalElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "معدل الإنجاز العام",
                                style = MaterialTheme.typography.labelMedium,
                                color = LightGray.copy(alpha = 0.7f)
                            )
                            Text(
                                text = "${uiState.completionRate}%",
                                style = MaterialTheme.typography.displaySmall,
                                fontWeight = FontWeight.Black,
                                color = PrimaryLimeGreen
                            )
                        }

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(DeepDark)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = PrimaryLimeGreen,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { uiState.completionRate / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = PrimaryLimeGreen,
                        trackColor = DeepDark
                    )
                }
            }
        }

        // 3. Quantitative Metrics (Pages, Quran, Water, Workout)
        item {
            Text(
                text = "الكميات والإنجازات المحققة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(uiState.metricsList) { metric ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = metric.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(text = metric.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                    Text(
                        text = metric.value,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryLimeGreen
                    )
                }
            }
        }

        // 4. Weekly Review Section (shown especially if selected, or at bottom)
        if (uiState.selectedPeriod == "WEEKLY_REVIEW") {
            item {
                Spacer(Modifier.height(8.dp))
                WeeklyReviewCard(
                    selectedDay = uiState.weeklyReviewDay,
                    onSelectDay = { viewModel.updateWeeklyReviewDay(it) },
                    reasons = uiState.commonReasons,
                    suggestions = uiState.suggestions
                )
            }
        }
    }
}

@Composable
fun WeeklyReviewCard(
    selectedDay: Int,
    onSelectDay: (Int) -> Unit,
    reasons: List<ReasonCount>,
    suggestions: List<String>
) {
    val strings = LocalAppStrings.current
    val days = listOf(
        5 to "الجمعة",
        6 to "السبت",
        7 to "الأحد",
        1 to "الإثنين",
        4 to "الخميس"
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, SecondaryLimeYellow.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.RateReview, contentDescription = null, tint = SecondaryLimeYellow)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = strings.weeklyReview,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(10.dp))

            Text(
                text = strings.weeklyReviewDay,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )

            Spacer(Modifier.height(6.dp))

            // Day Selector Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(days) { (dayNum, dayName) ->
                    FilterChip(
                        selected = selectedDay == dayNum,
                        onClick = { onSelectDay(dayNum) },
                        label = { Text(dayName, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Reasons Breakdown
            Text(
                text = strings.commonIncompleteReasons,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(8.dp))

            if (reasons.isEmpty()) {
                Text(
                    text = "لا توجد أسباب مسجلة لعدم الإكمال، أداؤك استثنائي!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = PrimaryLimeGreen
                )
            } else {
                reasons.take(4).forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "• ${item.reason}", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "${item.count} مرات",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusWarning
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Practical Suggestions
            Text(
                text = strings.practicalSuggestions,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(8.dp))

            suggestions.forEach { suggestion ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PrimaryLimeGreen.copy(alpha = 0.1f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TipsAndUpdates, contentDescription = null, tint = PrimaryLimeGreen, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(text = suggestion, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
