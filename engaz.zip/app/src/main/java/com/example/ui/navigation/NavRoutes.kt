package com.example.ui.navigation

object NavRoutes {
    const val DASHBOARD = "dashboard"
    const val HABITS = "habits"
    const val HEALTH = "health"
    const val FINANCE = "finance"
    const val GAMING = "gaming"
    const val TASKS = "tasks"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"
}
