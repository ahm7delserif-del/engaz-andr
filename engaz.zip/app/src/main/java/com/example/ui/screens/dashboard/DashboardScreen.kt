package com.example.ui.screens.dashboard

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.datastore.AppPreferences
import com.example.ui.components.ActiveTimerBanner
import com.example.ui.components.TaskCompletionDialog
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import com.example.util.DateUtils
import java.io.File

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    preferences: AppPreferences,
    onNavigateToSection: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val isArabic = preferences.language == "ar"

    val selectedItem = uiState.selectedItemForCompletion
    if (selectedItem != null) {
        TaskCompletionDialog(
            taskTitle = selectedItem.title,
            onDismiss = { viewModel.dismissCompletionDialog() },
            onCompleted = { viewModel.markItemCompleted(selectedItem) },
            onIncompleteWithReason = { reason -> viewModel.markItemIncompleteWithReason(selectedItem, reason) }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // 1. Hero / Header Card
        item {
            DashboardHeroCard(
                dateDisplay = DateUtils.getTodayDisplayString(isArabic),
                completionPercentage = uiState.completionPercentage,
                completedCount = uiState.completedCount,
                totalCount = uiState.totalCount,
                summary = uiState.topItemsSummary
            )
        }

        // 2. Active Timer Banner if any
        if (uiState.activeTimer != null) {
            item {
                ActiveTimerBanner(
                    timer = uiState.activeTimer,
                    onStopTimer = { viewModel.stopActiveTimer() },
                    onCompleteTask = { timer ->
                        val item = uiState.items.find { it.id == timer.activityId && it.type == timer.activityType }
                            ?: DashboardItem(
                                id = timer.activityId,
                                type = timer.activityType,
                                title = timer.activityTitle,
                                subtitle = "",
                                time = "",
                                durationMinutes = timer.totalDurationMinutes,
                                status = "PENDING"
                            )
                        viewModel.promptCompleteActivity(item)
                    }
                )
            }
        }

        // 3. Section Title
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.topPriorities,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${uiState.completedCount}/${uiState.totalCount}",
                    style = MaterialTheme.typography.labelLarge,
                    color = PrimaryLimeGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 4. Empty State or Items List
        if (uiState.items.isEmpty()) {
            item {
                DashboardEmptyState()
            }
        } else {
            items(uiState.items, key = { "${it.type}_${it.id}" }) { item ->
                DashboardItemCard(
                    item = item,
                    onStartTimer = { viewModel.startTimerForActivity(item) },
                    onItemClick = { viewModel.promptCompleteActivity(item) }
                )
            }
        }
    }
}

@Composable
fun DashboardHeroCard(
    dateDisplay: String,
    completionPercentage: Int,
    completedCount: Int,
    totalCount: Int,
    summary: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        color = MainCharcoal,
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = dateDisplay,
                        style = MaterialTheme.typography.labelLarge,
                        color = SecondaryLimeYellow,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "جدول إنجاز اليوم",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = LightGray
                    )
                }

                // Circular Progress Indicator
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(DeepDark)
                ) {
                    CircularProgressIndicator(
                        progress = { completionPercentage / 100f },
                        modifier = Modifier.fillMaxSize(),
                        color = PrimaryLimeGreen,
                        trackColor = MainCharcoal,
                        strokeWidth = 6.dp
                    )
                    Text(
                        text = "$completionPercentage%",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = PrimaryLimeGreen
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Summary Pill Box
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = DeepDark.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lightbulb,
                        contentDescription = null,
                        tint = SecondaryLimeYellow,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = summary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = LightGray.copy(alpha = 0.9f),
                        maxLines = 2
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardItemCard(
    item: DashboardItem,
    onStartTimer: () -> Unit,
    onItemClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    val (statusColor, statusLabel) = when (item.status) {
        "COMPLETED" -> StatusSuccess to strings.completed
        "IN_PROGRESS" -> StatusInfo to strings.inProgress
        "POSTPONED" -> StatusWarning to strings.postponed
        "OVERDUE" -> StatusError to strings.overdue
        "MISSED" -> StatusError to strings.missed
        else -> MaterialTheme.colorScheme.outline to strings.pending
    }

    val typeIcon: ImageVector = when (item.type) {
        "HABIT" -> Icons.Default.Psychology
        "WORKOUT" -> Icons.Default.FitnessCenter
        "FASTING" -> Icons.Default.NightsStay
        else -> Icons.Default.Assignment
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onItemClick() }
            .testTag("dashboard_item_${item.id}"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (item.status == "COMPLETED") StatusSuccess.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
        ),
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail or Category Icon
            if (!item.thumbnailUri.isNullOrBlank() && File(item.thumbnailUri).exists()) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(File(item.thumbnailUri))
                        .crossfade(true)
                        .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            } else {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (item.status == "COMPLETED") StatusSuccess.copy(alpha = 0.2f)
                            else PrimaryLimeGreen.copy(alpha = 0.15f)
                        )
                ) {
                    Icon(
                        imageVector = typeIcon,
                        contentDescription = null,
                        tint = if (item.status == "COMPLETED") StatusSuccess else PrimaryLimeGreen,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (item.subtitle.isNotBlank()) {
                    Text(
                        text = item.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        maxLines = 1
                    )
                }
                Spacer(Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (item.time.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Schedule,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp),
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Spacer(Modifier.width(3.dp))
                            Text(
                                text = item.time,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }

                    // Status Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = statusColor.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Start Button for activities with duration if not completed
            if (item.status != "COMPLETED" && item.durationMinutes > 0) {
                Spacer(Modifier.width(8.dp))
                FilledTonalButton(
                    onClick = onStartTimer,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = PrimaryLimeGreen.copy(alpha = 0.2f),
                        contentColor = PrimaryLimeGreen
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("start_button_${item.id}")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.start, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            } else if (item.status == "COMPLETED") {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = StatusSuccess,
                    modifier = Modifier
                        .size(28.dp)
                        .padding(end = 4.dp)
                )
            }
        }
    }
}

@Composable
fun DashboardEmptyState() {
    val strings = LocalAppStrings.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Checklist,
            contentDescription = null,
            tint = PrimaryLimeGreen.copy(alpha = 0.5f),
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = strings.emptyStateTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = strings.emptyStateDesc,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
