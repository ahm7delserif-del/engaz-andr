package com.example.ui.components

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

object ImageStorageHelper {

    fun saveImageLocally(context: Context, sourceUri: Uri, prefix: String = "img"): String? {
        return try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(sourceUri)
            if (inputStream == null) return null

            val directory = File(context.filesDir, "engaz_images")
            if (!directory.exists()) {
                directory.mkdirs()
            }

            val filename = "${prefix}_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg"
            val targetFile = File(directory, filename)

            FileOutputStream(targetFile).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
            inputStream.close()

            targetFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun deleteLocalImage(path: String?) {
        if (path.isNullOrBlank()) return
        try {
            val file = File(path)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
