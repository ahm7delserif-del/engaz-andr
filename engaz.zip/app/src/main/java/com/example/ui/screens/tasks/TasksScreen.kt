package com.example.ui.screens.tasks

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.TaskEntity
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import com.example.util.DateUtils

@Composable
fun TasksScreen(
    viewModel: TasksViewModel,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddTask() },
                containerColor = PrimaryLimeGreen,
                contentColor = NearBlack,
                modifier = Modifier.testTag("add_task_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = strings.addTask)
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Filters Row
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf(
                    "ALL" to "الكل",
                    "WORK" to strings.categoryWork,
                    "STUDY" to strings.categoryStudy,
                    "PROJECT" to strings.categoryProject,
                    "PENDING" to strings.pending,
                    "COMPLETED" to strings.completed
                )
                items(filters) { (key, label) ->
                    FilterChip(
                        selected = uiState.selectedFilter == key,
                        onClick = { viewModel.setFilter(key) },
                        label = { Text(label, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // Tasks List
            if (uiState.filteredTasks.isEmpty()) {
                TasksEmptyState()
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.filteredTasks, key = { it.id }) { task ->
                        TaskCard(
                            task = task,
                            onToggleStatus = { viewModel.toggleTaskStatus(task) },
                            onStartFocusTimer = { viewModel.startFocusTimer(task) },
                            onEdit = { viewModel.openEditTask(task) },
                            onDelete = { viewModel.promptDelete(task) }
                        )
                    }
                }
            }
        }

        // Add/Edit Dialog
        if (uiState.showAddEditDialog) {
            AddEditTaskDialog(
                task = uiState.selectedTaskForEdit,
                onDismiss = { viewModel.closeAddEditDialog() },
                onSave = { id, title, desc, cat, prio, date, time, dur, notes ->
                    viewModel.saveTask(id, title, desc, cat, prio, date, time, dur, notes)
                }
            )
        }

        // Delete Confirmation
        if (uiState.taskToDelete != null) {
            AlertDialog(
                onDismissRequest = { viewModel.dismissDelete() },
                title = { Text(strings.confirmDelete) },
                text = { Text(strings.confirmDeleteMsg) },
                confirmButton = {
                    Button(
                        onClick = { viewModel.confirmDelete() },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                    ) {
                        Text(strings.delete)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissDelete() }) {
                        Text(strings.cancel)
                    }
                }
            )
        }
    }
}

@Composable
fun TaskCard(
    task: TaskEntity,
    onToggleStatus: () -> Unit,
    onStartFocusTimer: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isCompleted = task.status == "COMPLETED"

    val priorityColor = when (task.priority) {
        "HIGH" -> StatusError
        "MEDIUM" -> StatusWarning
        else -> StatusInfo
    }

    val priorityLabel = when (task.priority) {
        "HIGH" -> strings.priorityHigh
        "MEDIUM" -> strings.priorityMedium
        else -> strings.priorityLow
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(
                1.dp,
                if (isCompleted) StatusSuccess.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                RoundedCornerShape(18.dp)
            ),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked = isCompleted,
                    onCheckedChange = { onToggleStatus() }
                )

                Spacer(Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface
                    )
                    if (task.description.isNotBlank()) {
                        Text(
                            text = task.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            maxLines = 2
                        )
                    }
                }

                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = strings.edit, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = strings.delete, tint = StatusError)
                }
            }

            Spacer(Modifier.height(8.dp))

            // Metadata row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Priority Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = priorityColor.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = priorityLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = priorityColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Category Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        val catLabel = when (task.category) {
                            "WORK" -> strings.categoryWork
                            "STUDY" -> strings.categoryStudy
                            else -> strings.categoryProject
                        }
                        Text(
                            text = catLabel,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = "${task.dueDate} • ${task.dueTime}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            if (!isCompleted && task.estimatedDurationMinutes > 0) {
                Spacer(Modifier.height(12.dp))
                FilledTonalButton(
                    onClick = onStartFocusTimer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.HourglassTop, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("بدء مؤقت التركيز (${task.estimatedDurationMinutes} دقيقة)")
                }
            }
        }
    }
}

@Composable
fun AddEditTaskDialog(
    task: TaskEntity?,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        title: String,
        description: String,
        category: String,
        priority: String,
        dueDate: String,
        dueTime: String,
        durationMinutes: Int,
        notes: String
    ) -> Unit
) {
    val strings = LocalAppStrings.current
    var title by remember { mutableStateOf(task?.title ?: "") }
    var description by remember { mutableStateOf(task?.description ?: "") }
    var category by remember { mutableStateOf(task?.category ?: "WORK") }
    var priority by remember { mutableStateOf(task?.priority ?: "MEDIUM") }
    var dueDate by remember { mutableStateOf(task?.dueDate ?: DateUtils.getTodayDateString()) }
    var dueTime by remember { mutableStateOf(task?.dueTime ?: "09:00") }
    var durationMinutesStr by remember { mutableStateOf(task?.estimatedDurationMinutes?.toString() ?: "30") }
    var notes by remember { mutableStateOf(task?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (task == null) strings.addTask else strings.edit) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(strings.taskTitle) },
                        modifier = Modifier.fillMaxWidth().testTag("task_title_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("الوصف أو الخطوات") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Category chips
                item {
                    Text("التصنيف", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = category == "WORK",
                            onClick = { category = "WORK" },
                            label = { Text(strings.categoryWork) }
                        )
                        FilterChip(
                            selected = category == "STUDY",
                            onClick = { category = "STUDY" },
                            label = { Text(strings.categoryStudy) }
                        )
                        FilterChip(
                            selected = category == "PROJECT",
                            onClick = { category = "PROJECT" },
                            label = { Text(strings.categoryProject) }
                        )
                    }
                }

                // Priority chips
                item {
                    Text("الأولوية", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = priority == "HIGH",
                            onClick = { priority = "HIGH" },
                            label = { Text(strings.priorityHigh) }
                        )
                        FilterChip(
                            selected = priority == "MEDIUM",
                            onClick = { priority = "MEDIUM" },
                            label = { Text(strings.priorityMedium) }
                        )
                        FilterChip(
                            selected = priority == "LOW",
                            onClick = { priority = "LOW" },
                            label = { Text(strings.priorityLow) }
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dueDate,
                            onValueChange = { dueDate = it },
                            label = { Text("تاريخ الإنجاز (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = dueTime,
                            onValueChange = { dueTime = it },
                            label = { Text("الوقت (09:00)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = durationMinutesStr,
                        onValueChange = { durationMinutesStr = it },
                        label = { Text("المدة المقدرة بالدقائق") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val dur = durationMinutesStr.toIntOrNull() ?: 30
                        onSave(
                            task?.id ?: 0L,
                            title.trim(),
                            description.trim(),
                            category,
                            priority,
                            dueDate.trim(),
                            dueTime.trim(),
                            dur,
                            notes.trim()
                        )
                    }
                }
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
fun TasksEmptyState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Assignment, contentDescription = null, tint = PrimaryLimeGreen.copy(alpha = 0.5f), modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(8.dp))
        Text(text = "لا توجد مهام مطابقة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            text = "أضف مهام عملك ودراستك ومشاريعك الشخصية لبدء جلسات التركيز الموجهة.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
