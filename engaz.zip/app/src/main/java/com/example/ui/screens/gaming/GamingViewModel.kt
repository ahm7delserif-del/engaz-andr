package com.example.ui.screens.gaming

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.GameEntity
import com.example.data.local.entity.GamingSessionEntity
import com.example.data.repository.GamingRepository
import com.example.data.repository.TimerRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class GamingUiState(
    val games: List<GameEntity> = emptyList(),
    val todaySessions: List<GamingSessionEntity> = emptyList(),
    val totalMinutesToday: Int = 0,
    val showAddGameDialog: Boolean = false,
    val selectedGameForSession: GameEntity? = null,
    val showSessionDurationDialog: Boolean = false,
    val gameToDelete: GameEntity? = null
)

class GamingViewModel(
    private val gamingRepository: GamingRepository,
    private val timerRepository: TimerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GamingUiState())
    val uiState: StateFlow<GamingUiState> = _uiState.asStateFlow()

    init {
        loadGamingData()
    }

    private fun loadGamingData() {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            combine(
                gamingRepository.getAllGames(),
                gamingRepository.getSessionsForDate(today)
            ) { games, todaySessions ->
                val minutesToday = todaySessions.sumOf { it.durationMinutes }
                GamingUiState(
                    games = games,
                    todaySessions = todaySessions,
                    totalMinutesToday = minutesToday
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun openAddGame() {
        _uiState.update { it.copy(showAddGameDialog = true) }
    }

    fun closeAddGame() {
        _uiState.update { it.copy(showAddGameDialog = false) }
    }

    fun addGame(name: String, thumbnailUri: String?) {
        viewModelScope.launch {
            gamingRepository.insertGame(
                GameEntity(
                    name = name,
                    thumbnailUri = thumbnailUri
                )
            )
            closeAddGame()
        }
    }

    fun promptDeleteGame(game: GameEntity) {
        _uiState.update { it.copy(gameToDelete = game) }
    }

    fun dismissDeleteGame() {
        _uiState.update { it.copy(gameToDelete = null) }
    }

    fun confirmDeleteGame() {
        val game = _uiState.value.gameToDelete ?: return
        viewModelScope.launch {
            gamingRepository.deleteGame(game)
            dismissDeleteGame()
        }
    }

    fun openStartSession(game: GameEntity) {
        _uiState.update { it.copy(selectedGameForSession = game, showSessionDurationDialog = true) }
    }

    fun closeSessionDurationDialog() {
        _uiState.update { it.copy(showSessionDurationDialog = false, selectedGameForSession = null) }
    }

    fun startSession(game: GameEntity, durationMinutes: Int) {
        val today = DateUtils.getTodayDateString()
        viewModelScope.launch {
            gamingRepository.recordSession(
                gameId = game.id,
                gameName = game.name,
                durationMinutes = durationMinutes,
                date = today
            )
            timerRepository.startTimer(
                activityId = game.id,
                activityType = "GAME",
                activityTitle = "جلسة لعب: ${game.name}",
                durationMinutes = durationMinutes
            )
            closeSessionDurationDialog()
        }
    }
}
