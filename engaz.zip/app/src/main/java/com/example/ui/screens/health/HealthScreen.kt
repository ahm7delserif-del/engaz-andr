package com.example.ui.screens.health

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.WorkoutEntity
import com.example.ui.components.ImageStorageHelper
import com.example.ui.localization.LocalAppStrings
import com.example.ui.theme.*
import com.example.util.DateUtils
import java.io.File

@Composable
fun HealthScreen(
    viewModel: HealthViewModel,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddWorkout() },
                containerColor = PrimaryLimeGreen,
                contentColor = NearBlack,
                modifier = Modifier.testTag("add_workout_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = strings.addWorkout)
            }
        },
        modifier = modifier
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Water Tracker Card
            item {
                WaterTrackerCard(
                    currentMl = uiState.todayWaterMl,
                    goalMl = uiState.waterGoalMl,
                    onAddWater = { viewModel.addWater(it) },
                    onResetWater = { viewModel.resetWater() }
                )
            }

            // 2. Fasting Tracker Card
            item {
                FastingTrackerCard(
                    plan = uiState.todayFastingPlan,
                    onConfigureFasting = { viewModel.openFastingDialog() }
                )
            }

            // 3. Health Calendar Mini-Strip
            item {
                HealthCalendarStrip(
                    workouts = uiState.allWorkouts,
                    fastingPlans = uiState.allFastingPlans
                )
            }

            // 4. Workouts Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.workoutsTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${uiState.todayWorkouts.size} تمارين اليوم",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            // 5. Workouts List
            if (uiState.todayWorkouts.isEmpty()) {
                item {
                    WorkoutsEmptyState()
                }
            } else {
                items(uiState.todayWorkouts, key = { it.id }) { workout ->
                    WorkoutCard(
                        workout = workout,
                        onToggleCompleted = { viewModel.toggleWorkoutCompleted(workout) },
                        onStartTimer = { viewModel.startWorkoutTimer(workout) },
                        onEdit = { viewModel.openEditWorkout(workout) },
                        onDelete = { viewModel.promptDeleteWorkout(workout) }
                    )
                }
            }
        }

        // Add/Edit Workout Dialog
        if (uiState.showAddWorkoutDialog) {
            AddEditWorkoutDialog(
                workout = uiState.selectedWorkoutForEdit,
                onDismiss = { viewModel.closeWorkoutDialog() },
                onSave = { id, title, desc, date, time, dur, thumb ->
                    viewModel.saveWorkout(id, title, desc, date, time, dur, thumb)
                }
            )
        }

        // Fasting Plan Dialog
        if (uiState.showFastingDialog) {
            FastingPlanDialog(
                currentPlan = uiState.todayFastingPlan,
                onDismiss = { viewModel.closeFastingDialog() },
                onSelectPlan = { type, status -> viewModel.setFastingPlanToday(type, status) },
                onRemovePlan = { viewModel.removeFastingToday() }
            )
        }

        // Delete Workout Dialog
        if (uiState.workoutToDelete != null) {
            AlertDialog(
                onDismissRequest = { viewModel.dismissDeleteWorkout() },
                title = { Text(strings.confirmDelete) },
                text = { Text(strings.confirmDeleteMsg) },
                confirmButton = {
                    Button(
                        onClick = { viewModel.confirmDeleteWorkout() },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                    ) {
                        Text(strings.delete)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissDeleteWorkout() }) {
                        Text(strings.cancel)
                    }
                }
            )
        }
    }
}

@Composable
fun WaterTrackerCard(
    currentMl: Int,
    goalMl: Int,
    onAddWater: (Int) -> Unit,
    onResetWater: () -> Unit
) {
    val strings = LocalAppStrings.current
    val progress = (currentMl.toFloat() / goalMl.toFloat()).coerceIn(0f, 1f)
    val percentage = (progress * 100).toInt()

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MainCharcoal,
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusInfo.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = null,
                            tint = StatusInfo,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = strings.waterTracker,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = LightGray
                        )
                        Text(
                            text = strings.waterGoal,
                            style = MaterialTheme.typography.bodySmall,
                            color = LightGray.copy(alpha = 0.7f)
                        )
                    }
                }

                TextButton(onClick = onResetWater) {
                    Text(strings.resetWater, color = StatusError, style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(Modifier.height(14.dp))

            // Progress text and bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$currentMl / $goalMl مل",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = StatusInfo
                )
                Text(
                    text = "$percentage%",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (percentage >= 100) PrimaryLimeGreen else LightGray
                )
            }

            Spacer(Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = StatusInfo,
                trackColor = DeepDark
            )

            Spacer(Modifier.height(14.dp))

            // Quick Add Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = { onAddWater(250) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("+250 مل", style = MaterialTheme.typography.labelMedium)
                }
                FilledTonalButton(
                    onClick = { onAddWater(500) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("+500 مل", style = MaterialTheme.typography.labelMedium)
                }
                FilledTonalButton(
                    onClick = { onAddWater(1000) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("+1 لتر", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun FastingTrackerCard(
    plan: com.example.data.local.entity.FastingPlanEntity?,
    onConfigureFasting: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isFastingActive = plan != null && plan.status != "BROKEN"

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isFastingActive) PrimaryLimeGreen.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
        ),
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SecondaryLimeYellow.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.NightsStay,
                        contentDescription = null,
                        tint = SecondaryLimeYellow,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = strings.fastingTracker,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (plan == null) "لم يتم تحديد صيام لليوم"
                        else if (plan.type == "SUNNAH_MON_THU") "سنة الإثنين والخميس"
                        else "صيام يوم مخصص",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            Button(
                onClick = onConfigureFasting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isFastingActive) StatusSuccess else PrimaryLimeGreen
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (plan == null) strings.markFastingToday else "تعديل")
            }
        }
    }
}

@Composable
fun HealthCalendarStrip(
    workouts: List<WorkoutEntity>,
    fastingPlans: List<com.example.data.local.entity.FastingPlanEntity>
) {
    val past7Days = remember { DateUtils.getPastNDays(7) }
    val today = DateUtils.getTodayDateString()

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "تقويم الأسبوع الصحي",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                past7Days.forEach { date ->
                    val isToday = (date == today)
                    val hasWorkout = workouts.any { it.date == date && it.status == "COMPLETED" }
                    val hasFasting = fastingPlans.any { it.date == date && it.status == "COMPLETED" }
                    val dayName = DateUtils.getWeekdayNameForDate(date)

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isToday) PrimaryLimeGreen.copy(alpha = 0.15f) else androidx.compose.ui.graphics.Color.Transparent)
                            .padding(6.dp)
                    ) {
                        Text(
                            text = dayName,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                            color = if (isToday) PrimaryLimeGreen else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (hasWorkout) PrimaryLimeGreen else MaterialTheme.colorScheme.surfaceVariant)
                            )
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (hasFasting) SecondaryLimeYellow else MaterialTheme.colorScheme.surfaceVariant)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkoutCard(
    workout: WorkoutEntity,
    onToggleCompleted: () -> Unit,
    onStartTimer: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isCompleted = workout.status == "COMPLETED"

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(
                1.dp,
                if (isCompleted) StatusSuccess.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                RoundedCornerShape(18.dp)
            ),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Thumbnail
                if (!workout.thumbnailUri.isNullOrBlank() && File(workout.thumbnailUri).exists()) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(File(workout.thumbnailUri))
                            .crossfade(true)
                            .build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                } else {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(PrimaryLimeGreen.copy(alpha = 0.15f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.FitnessCenter,
                            contentDescription = null,
                            tint = PrimaryLimeGreen,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = workout.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${workout.time} • ${workout.durationMinutes} دقيقة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(Modifier.height(2.dp))
                    // Dual Reminder Badge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = SecondaryLimeYellow,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "تنبيه مزدوج (قبل 10د وعند الموعد)",
                            style = MaterialTheme.typography.labelSmall,
                            color = SecondaryLimeYellow
                        )
                    }
                }

                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = strings.edit, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = strings.delete, tint = StatusError)
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onStartTimer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.start)
                }

                Button(
                    onClick = onToggleCompleted,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCompleted) StatusSuccess else PrimaryLimeGreen
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (isCompleted) strings.completed else strings.complete)
                }
            }
        }
    }
}

@Composable
fun AddEditWorkoutDialog(
    workout: WorkoutEntity?,
    onDismiss: () -> Unit,
    onSave: (id: Long, title: String, desc: String, date: String, time: String, dur: Int, thumb: String?) -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    var title by remember { mutableStateOf(workout?.title ?: "") }
    var description by remember { mutableStateOf(workout?.description ?: "") }
    var date by remember { mutableStateOf(workout?.date ?: DateUtils.getTodayDateString()) }
    var time by remember { mutableStateOf(workout?.time ?: "07:00") }
    var durationMinutesStr by remember { mutableStateOf(workout?.durationMinutes?.toString() ?: "45") }
    var thumbnailUri by remember { mutableStateOf(workout?.thumbnailUri) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val saved = ImageStorageHelper.saveImageLocally(context, uri, "workout")
            if (saved != null) thumbnailUri = saved
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (workout == null) strings.addWorkout else strings.edit) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان التمرين (كارديو، حديد، جري)") },
                    modifier = Modifier.fillMaxWidth().testTag("workout_title_input")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("الوصف أو تفاصيل التمرين") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("التاريخ (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("الوقت (07:00)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = durationMinutesStr,
                    onValueChange = { durationMinutesStr = it },
                    label = { Text("المدة بالدقائق") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Thumbnail
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("الصورة:", style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(
                        onClick = {
                            photoPicker.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        }
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (thumbnailUri == null) "اختيار صورة" else "تغيير")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val dur = durationMinutesStr.toIntOrNull() ?: 45
                        onSave(workout?.id ?: 0L, title.trim(), description.trim(), date.trim(), time.trim(), dur, thumbnailUri)
                    }
                }
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun FastingPlanDialog(
    currentPlan: com.example.data.local.entity.FastingPlanEntity?,
    onDismiss: () -> Unit,
    onSelectPlan: (type: String, status: String) -> Unit,
    onRemovePlan: () -> Unit
) {
    val strings = LocalAppStrings.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.fastingTracker) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onSelectPlan("SUNNAH_MON_THU", "PLANNED") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(strings.fastingMondayThursday)
                }

                Button(
                    onClick = { onSelectPlan("CUSTOM", "PLANNED") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(strings.fastingCustomDay)
                }

                if (currentPlan != null) {
                    FilledTonalButton(
                        onClick = { onSelectPlan(currentPlan.type, "COMPLETED") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(strings.fastingStatusCompleted)
                    }

                    OutlinedButton(
                        onClick = onRemovePlan,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إلغاء تسجيل الصيام لليوم", color = StatusError)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun WorkoutsEmptyState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.FitnessCenter,
            contentDescription = null,
            tint = PrimaryLimeGreen.copy(alpha = 0.5f),
            modifier = Modifier.size(54.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "لا توجد تمارين مجدولة لليوم",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "اضغط على زر الإضافة لجدولة تمارينك الرياضية مع التنبيهات المزدوجة.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
    }
}
