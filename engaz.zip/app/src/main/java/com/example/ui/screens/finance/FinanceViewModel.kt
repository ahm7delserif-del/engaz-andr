package com.example.ui.screens.finance

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.FinanceCommitmentEntity
import com.example.data.local.entity.FinanceExpenseEntity
import com.example.data.local.entity.SavingsGoalEntity
import com.example.data.repository.FinanceRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class FinanceUiState(
    val monthlyIncome: Double = 0.0,
    val commitments: List<FinanceCommitmentEntity> = emptyList(),
    val expenses: List<FinanceExpenseEntity> = emptyList(),
    val savingsGoals: List<SavingsGoalEntity> = emptyList(),
    val totalCommitments: Double = 0.0,
    val totalExpensesThisMonth: Double = 0.0,
    val remainingBalance: Double = 0.0,
    val isBudgetCloseToLimit: Boolean = false,
    val showAddExpenseDialog: Boolean = false,
    val showAddCommitmentDialog: Boolean = false,
    val showAddGoalDialog: Boolean = false,
    val showSetIncomeDialog: Boolean = false
)

class FinanceViewModel(private val financeRepository: FinanceRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(FinanceUiState())
    val uiState: StateFlow<FinanceUiState> = _uiState.asStateFlow()

    init {
        loadFinanceData()
    }

    private fun loadFinanceData() {
        val currentMonth = DateUtils.getCurrentMonthString()
        viewModelScope.launch {
            combine(
                financeRepository.getMonthlyIncome(currentMonth),
                financeRepository.getAllCommitments(),
                financeRepository.getExpensesForMonth(currentMonth),
                financeRepository.getAllSavingsGoals()
            ) { incomeEntity, commitments, expenses, goals ->
                val income = incomeEntity?.incomeAmount ?: 0.0
                val totalCommit = commitments.sumOf { it.amount }
                val totalExp = expenses.sumOf { it.amount }
                val remaining = income - totalCommit - totalExp

                val warning = (income > 0) && (remaining < (income * 0.15))

                FinanceUiState(
                    monthlyIncome = income,
                    commitments = commitments,
                    expenses = expenses,
                    savingsGoals = goals,
                    totalCommitments = totalCommit,
                    totalExpensesThisMonth = totalExp,
                    remainingBalance = remaining,
                    isBudgetCloseToLimit = warning
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun setMonthlyIncome(amount: Double) {
        val currentMonth = DateUtils.getCurrentMonthString()
        viewModelScope.launch {
            financeRepository.setMonthlyIncome(currentMonth, amount)
            _uiState.update { it.copy(showSetIncomeDialog = false) }
        }
    }

    fun addCommitment(title: String, amount: Double, category: String, dueDay: Int) {
        viewModelScope.launch {
            financeRepository.insertCommitment(
                FinanceCommitmentEntity(
                    title = title,
                    amount = amount,
                    category = category,
                    dueDayOfMonth = dueDay
                )
            )
            _uiState.update { it.copy(showAddCommitmentDialog = false) }
        }
    }

    fun toggleCommitmentPaid(commitment: FinanceCommitmentEntity) {
        viewModelScope.launch {
            financeRepository.updateCommitment(
                commitment.copy(isPaidThisMonth = !commitment.isPaidThisMonth)
            )
        }
    }

    fun deleteCommitment(commitment: FinanceCommitmentEntity) {
        viewModelScope.launch {
            financeRepository.deleteCommitment(commitment)
        }
    }

    fun addExpense(title: String, amount: Double, category: String, date: String, notes: String) {
        viewModelScope.launch {
            financeRepository.insertExpense(
                FinanceExpenseEntity(
                    title = title,
                    amount = amount,
                    category = category,
                    date = date,
                    notes = notes
                )
            )
            _uiState.update { it.copy(showAddExpenseDialog = false) }
        }
    }

    fun deleteExpense(expense: FinanceExpenseEntity) {
        viewModelScope.launch {
            financeRepository.deleteExpense(expense)
        }
    }

    fun addSavingsGoal(title: String, target: Double, current: Double, targetDate: String, notes: String) {
        viewModelScope.launch {
            financeRepository.insertSavingsGoal(
                SavingsGoalEntity(
                    title = title,
                    targetAmount = target,
                    currentAmount = current,
                    targetDate = targetDate,
                    notes = notes
                )
            )
            _uiState.update { it.copy(showAddGoalDialog = false) }
        }
    }

    fun updateSavingsProgress(goal: SavingsGoalEntity, newAmount: Double) {
        viewModelScope.launch {
            financeRepository.updateSavingsGoal(goal.copy(currentAmount = newAmount))
        }
    }

    fun deleteSavingsGoal(goal: SavingsGoalEntity) {
        viewModelScope.launch {
            financeRepository.deleteSavingsGoal(goal)
        }
    }

    fun openSetIncome() = _uiState.update { it.copy(showSetIncomeDialog = true) }
    fun closeSetIncome() = _uiState.update { it.copy(showSetIncomeDialog = false) }

    fun openAddCommitment() = _uiState.update { it.copy(showAddCommitmentDialog = true) }
    fun closeAddCommitment() = _uiState.update { it.copy(showAddCommitmentDialog = false) }

    fun openAddExpense() = _uiState.update { it.copy(showAddExpenseDialog = true) }
    fun closeAddExpense() = _uiState.update { it.copy(showAddExpenseDialog = false) }

    fun openAddGoal() = _uiState.update { it.copy(showAddGoalDialog = true) }
    fun closeAddGoal() = _uiState.update { it.copy(showAddGoalDialog = false) }
}
