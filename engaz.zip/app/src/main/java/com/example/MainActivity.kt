package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.datastore.AppPreferences
import com.example.data.datastore.UserPreferencesRepository
import com.example.data.local.AppDatabase
import com.example.data.reminder.NotificationScheduler
import com.example.data.repository.*
import com.example.ui.navigation.MainAppContainer
import com.example.ui.screens.dashboard.DashboardViewModel
import com.example.ui.screens.finance.FinanceViewModel
import com.example.ui.screens.gaming.GamingViewModel
import com.example.ui.screens.habits.HabitsViewModel
import com.example.ui.screens.health.HealthViewModel
import com.example.ui.screens.reports.ReportsViewModel
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.screens.tasks.TasksViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val scheduler = NotificationScheduler(applicationContext)
        val userPrefsRepo = UserPreferencesRepository(applicationContext)

        val taskRepo = TaskRepository(database.taskDao(), scheduler)
        val habitRepo = HabitRepository(database.habitDao(), scheduler)
        val healthRepo = HealthRepository(database.healthDao(), scheduler)
        val financeRepo = FinanceRepository(database.financeDao())
        val gamingRepo = GamingRepository(database.gamingDao())
        val timerRepo = TimerRepository(database.timerDao(), scheduler)

        setContent {
            // Graceful Notification Permission Request on Android 13+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                var hasNotificationPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    hasNotificationPermission = isGranted
                }

                LaunchedEffect(Unit) {
                    if (!hasNotificationPermission) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            val preferences by userPrefsRepo.userPreferencesFlow
                .collectAsStateWithLifecycle(initialValue = AppPreferences())

            val dashboardVm: DashboardViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return DashboardViewModel(taskRepo, habitRepo, healthRepo, timerRepo) as T
                    }
                }
            )

            val habitsVm: HabitsViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return HabitsViewModel(habitRepo, timerRepo) as T
                    }
                }
            )

            val healthVm: HealthViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return HealthViewModel(healthRepo, timerRepo) as T
                    }
                }
            )

            val financeVm: FinanceViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return FinanceViewModel(financeRepo) as T
                    }
                }
            )

            val gamingVm: GamingViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return GamingViewModel(gamingRepo, timerRepo) as T
                    }
                }
            )

            val tasksVm: TasksViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return TasksViewModel(taskRepo, timerRepo) as T
                    }
                }
            )

            val reportsVm: ReportsViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return ReportsViewModel(taskRepo, habitRepo, healthRepo, userPrefsRepo) as T
                    }
                }
            )

            val settingsVm: SettingsViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return SettingsViewModel(userPrefsRepo) as T
                    }
                }
            )

            MainAppContainer(
                preferences = preferences,
                dashboardViewModel = dashboardVm,
                habitsViewModel = habitsVm,
                healthViewModel = healthVm,
                financeViewModel = financeVm,
                gamingViewModel = gamingVm,
                tasksViewModel = tasksVm,
                reportsViewModel = reportsVm,
                settingsViewModel = settingsVm
            )
        }
    }
}

