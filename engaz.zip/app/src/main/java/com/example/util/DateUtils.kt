package com.example.util

import java.text.SimpleDateFormat
import java.util.*

object DateUtils {

    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun getCurrentMonthString(): String {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.US)
        return sdf.format(Date())
    }

    fun getCurrentYearString(): String {
        val sdf = SimpleDateFormat("yyyy", Locale.US)
        return sdf.format(Date())
    }

    fun getTodayDisplayString(isArabic: Boolean): String {
        val locale = if (isArabic) Locale("ar") else Locale.ENGLISH
        val sdf = SimpleDateFormat("EEEE، d MMMM yyyy", locale)
        return sdf.format(Date())
    }

    fun getWeekdayName(date: Date = Date()): String {
        val cal = Calendar.getInstance()
        cal.time = date
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SUNDAY -> "SUN"
            Calendar.MONDAY -> "MON"
            Calendar.TUESDAY -> "TUE"
            Calendar.WEDNESDAY -> "WED"
            Calendar.THURSDAY -> "THU"
            Calendar.FRIDAY -> "FRI"
            Calendar.SATURDAY -> "SAT"
            else -> "ALL"
        }
    }

    fun getDayOfWeekNumber(date: Date = Date()): Int {
        val cal = Calendar.getInstance()
        cal.time = date
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            Calendar.SUNDAY -> 7
            else -> 1
        }
    }

    fun isHabitScheduledForDate(
        recurrenceType: String,
        recurrenceDays: String,
        startDate: String?,
        endDate: String?,
        targetDate: String
    ): Boolean {
        // Date range checks
        if (!startDate.isNullOrBlank() && targetDate < startDate) return false
        if (!endDate.isNullOrBlank() && targetDate > endDate) return false

        return when (recurrenceType) {
            "DAILY" -> true
            "WEEKDAYS" -> {
                val targetDayName = getWeekdayNameForDate(targetDate)
                recurrenceDays.contains(targetDayName, ignoreCase = true)
            }
            "DATE_RANGE" -> true
            else -> true
        }
    }

    fun getWeekdayNameForDate(dateStr: String): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(dateStr) ?: Date()
            getWeekdayName(date)
        } catch (e: Exception) {
            "ALL"
        }
    }

    fun getPastNDays(n: Int): List<String> {
        val list = mutableListOf<String>()
        val cal = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for (i in 0 until n) {
            list.add(sdf.format(cal.time))
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return list.reversed()
    }
}
